package edu.udel.jguarni.app.blockevader;

import android.widget.TextView;
import android.widget.Toast;
import edu.udel.jatlas.gameframework.GameStateListener;
import edu.udel.jguarni.blockevader.EvaderState;

public class Scoreboard extends TextView implements GameStateListener {
    private int level;
    private EvaderActivity activity;
    
    public Scoreboard(EvaderActivity context) {
        super(context);
        activity = context;
    }

    public void onStateChange(Object game) {
        if (game == activity.getCurrentGame()) {
            EvaderState state = activity.getCurrentGame().getCurrentState();

            String message = "Score=" + state.getScore() + " Level=" + state.getLevel();
            if (state.isEnd()) {
                message = "Oh no you died! " + message;
            }
            setText(message);
    
            if (level != state.getLevel()) {
                level = state.getLevel();
                if (level > 0) {
                    Toast.makeText(getContext(), "Level " + level + "!", 1000).show();
                }
            }
        }
    }

}
