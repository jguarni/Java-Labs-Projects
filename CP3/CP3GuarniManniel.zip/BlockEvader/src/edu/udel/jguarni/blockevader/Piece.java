package edu.udel.jguarni.blockevader;

import java.util.LinkedList;

import edu.udel.jatlas.gameframework.Position;
import edu.udel.jguarni.blockevader.EvaderState;
import edu.udel.jguarni.blockevader.Piece;

public abstract class Piece<T extends Piece<T>> {
	public static final int UP = 3;
	public static final int STILL = 0;
	public static final int DOWN = 2;
	public static final int LEFT = 1;

	protected Position position;
	protected LinkedList<Position> linkedpos;

	protected Piece(Position position) {
		this.position = position;
	}
	protected Piece(LinkedList<Position> linkedpos) {
		this.linkedpos = linkedpos;
	}

	public abstract T copy();

	public Position getPosition() {
		return position;
	}

	public void setPosition(Position position) {
		this.position = position;
	}
    public void onTick(EvaderState state) {
        
    }
  

	protected void move(int direction, EvaderState state) {
		
		}


	public static Position next(Position p, int direction) {
		if (direction == STILL) {
			return new Position(p.getRow(), p.getCol());
		} else if (direction == DOWN) {
			return new Position(p.getRow() + 1, p.getCol());
		} else if (direction == LEFT) {
			return new Position(p.getRow(), p.getCol() - 1);
		} else if (direction == UP) {
			return new Position(p.getRow() - 1, p.getCol());
		} else {
			return p;
		}
	}

}
