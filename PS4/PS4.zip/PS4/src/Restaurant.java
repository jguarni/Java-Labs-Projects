import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

// A restaurant is a place that servces food.
public class Restaurant extends CalorieComparator implements Colorful {
	//Creates an instance of a restaurant.
	public Restaurant() {
	}
	//A list to store edible items.
	List<Edible> Ediblelist = new ArrayList<Edible>();
	//Adds a new edible item to the restaurants edible list.
	public void addEdibleItem(Edible item) {

		Ediblelist.add(item);
	}
	//A method to order a list of edible items by the number of calories in each edible item.
	public List<Edible> orderByCalories() {

		Collections.sort(Ediblelist, new CalorieComparator());

		return Ediblelist;
	}
	//A method that gets the menu from an edible list of food and prints the menu to the user.
	public String getMenu() {
		String menu = "";

		for (Edible ele : Ediblelist) {
			if (ele.getClass().getName() == "NavalOrange") {
				if (ele.getCalories() >= 100) {
					menu = menu + "ReallyBigNavalOrange" + "\n";
				} else {
					menu = menu + "NavalOrange" + "\n";
				}
			} else {
				menu = menu + ele.getClass().getName() + "\n";
			}
		}
		return menu;
	}

	@Override
	//A method to determine if an edible item is colorful or not.
	public List<Colorful> getColorfulItems() {

		List<Colorful> Colorlist = new ArrayList<Colorful>();

		for (int i = 0; i < this.Ediblelist.size(); i++) {
			if ((Ediblelist.get(i) instanceof Orange)
					|| (Ediblelist.get(i) instanceof IceCream)) {
				Colorlist.add((Colorful) Ediblelist.get(i));
			}
		}
		return Colorlist;
	}
}
