package edu.udel.jatlas.tictactoe.android;

import android.graphics.PixelFormat;
import android.opengl.GLSurfaceView;
import android.util.Log;
import edu.udel.jatlas.gameframework.GameStateListener;
import edu.udel.jatlas.tictactoe.TicTacToe5x5Game;
import edu.udel.jatlas.tictactoe.TicTacToe5x5Piece;

public class TicTacToe5x5View3D extends GLSurfaceView implements GameStateListener {
    private Shape3dRenderer renderer;
    private TicTacToe5x5Game lastGame;
    private TicTacToe5x5Activity activity;
    
    private Model3d model_X;
    private Model3d model_O;
    private Model3d model_grid;
    private Model3d model_BlockedSquare;
    
    
    public TicTacToe5x5View3D(TicTacToe5x5Activity activity) {
        super(activity);
        this.activity = activity;
        init();
    }
    

    private void init() {
        try {
            renderer = new Shape3dRenderer();
            
            // We want an 8888 pixel format because that's required for
            // a translucent window.
            // And we want a depth buffer.
            setEGLConfigChooser(8, 8, 8, 8, 16, 0);
            getHolder().setFormat(PixelFormat.TRANSLUCENT);
            setZOrderOnTop(true);
            
            setRenderer(renderer);
            
            float[] blue = new float[] { 0, 0, 1, 1f };
            float[] red = new float[] { 1, 0, 0, 1f };
            float[] white = new float[] {1f, 1f, 1f, 1f};

            model_X = new Piece1(0.38f, blue);
            //model_X = new TexturedSquare(0.38f, blue, activity, "images/wall.png", renderer); // a blue mask over the wall.png texture
            
            model_O = new Piece2(0.38f, red);
            //model_O = new TexturedSquare(0.38f, white, activity, "images/wall.png", renderer); // makes player O use the wall.png texture
            
            model_BlockedSquare = new Square(0.38f, white);
            
            model_grid = new Grid(5, 5, 0.02f, white);
        }
        catch (Exception e) {
            // no 3d for you!
            Log.e("TicTacToe5x5", "3d initialization failed", e);
        }
    }

    
    public void onStateChange(Object game) {
        if (game == this.activity.getCurrentGame()) {
            updateRenderer();
        }
    }


    protected void updateRenderer() {
        // because 3d shapes are expensive to create, it is better
        //  to find out if the shape is new to our game (i.e. it was
        //  just placed).  If it is new, create a new Shape3d.  
        
        // If it already exists we update the renderer to let it know
        //  the shape is still active, but otherwise do nothing 
        //  (because in tic tac toe pieces do not move during the game other than animation).
        //
        // If your game has movement and you want to implement 3d graphics,
        // you will need to store an identifier in your
        // objects that will correspond to the Piece. This could be the Shape3d itself, 
        // but you may want to consult the professor to make sure you map the game state
        // piece to the 3d shape properly.
        if (lastGame != activity.getCurrentGame()) {
            // if they started a new game since the last time we draw shapes to the renderer,
            //  clear all the old shapes
            renderer.clearShapes();
            
            // add the basic grid shape
            renderer.addShape("GRID", new AnimatedShape3d(model_grid));
            renderer.addShape("BLOCKED", new AnimatedShape3d(model_BlockedSquare));
            lastGame = activity.getCurrentGame();
        }
        
        // allows us to mark the current shapes
        renderer.mark();
        
        TicTacToe5x5Piece[][] board = activity.getCurrentGame().getCurrentState().getBoard();
        for (int row = 0; row < board.length; row++) {
            for (int col = 0; col < board[row].length; col++) {
                int identifier = row * 5 + col; // gives us a number between 0 and 24
                Shape3d shape = renderer.getShape(identifier);
                // do we need to create the 3d shape?
                if (shape == null) {
                    if (board[row][col].getSymbol() == 'x') {
                        shape = new AnimatedShape3d(model_X);
                    }
                    else if (board[row][col].getSymbol() == 'o') {
                        shape = new AnimatedShape3d(model_O);
                    }
                    
                    if (shape != null) {
                        renderer.addShape(identifier, shape);
                        // set the initial position of the shape
                        // need to reverse the position of the row since lower left is 0,0 in opengl

                        // this also starts the shape at a height of 0
                        // YOU NEED TO CHANGE THIS to 2 IF YOU WANT TO SEE THE DROP ANIMATION!
                        shape.setPosition(-0.8f+col*0.4f, 0.8f-(row*0.4f), 2.0f);
                    }
                }
                
                // ok now update the 3d shape
                if (shape != null) {
                    // if your game has shapes that move you will want to mutate
                    // their position here as well
                    
                    // tells the mark/sweep process that the shape of the given identifier is still
                    // active
                    renderer.update(identifier);
                }
            }
        }
        
        renderer.update("GRID"); // force renderer not to drop the grid
        renderer.update("BLOCKED"); // force renderer not to drop the blocked square
        
        // removes any shapes that are not still active from the renderer
        renderer.sweep();
    }
}
