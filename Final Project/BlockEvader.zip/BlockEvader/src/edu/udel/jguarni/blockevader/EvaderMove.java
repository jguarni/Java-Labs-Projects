package edu.udel.jguarni.blockevader;

import edu.udel.jatlas.gameframework.Move;
import edu.udel.jatlas.gameframework.Position;
import edu.udel.jguarni.blockevader.EvaderState;

/**
 * Really doesn't do anything except define that a SnakeMove implements Move
 * for SnakeStates.
 *  
 * @author jatlas
 */
public abstract class EvaderMove implements Move<EvaderState> {

}
