package edu.udel.jatlas.tictactoe;


import java.util.Arrays;
import java.util.List;

import junit.framework.TestCase;

public class TicTacToe5x5Tests extends TestCase {
    public static final TicTacToe5x5Piece X = new TicTacToe5x5Piece('x');
    public static final TicTacToe5x5Piece O = new TicTacToe5x5Piece('o');
    public static final TicTacToe5x5Piece E = new TicTacToe5x5EmptyPiece();
    public static final TicTacToe5x5Piece B = new TicTacToe5x5BlockedPiece();
    
    // an example empty board (score 0 for x, 0 for o)
    public static final TicTacToe5x5Piece[][] BOARD0 = 
    {{E, E, E, E, E},
     {E, E, E, E, E},
     {E, E, B, E, E},
     {E, E, E, E, E},
     {E, E, E, E, E}};
    
    // an example board after 2 turns each (score 1 for x, 2 for o)
    public static final TicTacToe5x5Piece[][] BOARD1 = 
    {{X, E, E, E, E},
     {E, E, E, E, O},
     {E, E, B, O, E},
     {X, E, E, E, E},
     {E, E, E, E, E}};
                                       
    // an example board mid-game (score 2 for x, 3 for o)
    public static final TicTacToe5x5Piece[][] BOARD2 = 
    {{X, O, O, E, X},
     {X, E, O, E, O},
     {E, E, B, O, E},
     {X, O, X, X, E},
     {E, E, E, E, E}};

    // an example board where player x has won (score 4 for x, 3 for o)
    public static final TicTacToe5x5Piece[][] BOARD3 = 
    {{X, O, O, E, X},
     {X, E, O, E, O},
     {X, E, B, O, E},
     {X, O, X, X, E},
     {E, E, E, E, E}};
    
    // an example board where nobody has won (score 3 for x, 3 for o) but there are no more moves
    public static final TicTacToe5x5Piece[][] BOARD4 = 
    {{X, O, O, O, X},
     {O, O, O, X, O},
     {X, X, B, O, X},
     {X, O, X, X, X},
     {O, X, O, O, X}};
    
    public void test_copy() {
        // use the initial state from TicTacToe5x5
        TicTacToe5x5State state = new TicTacToe5x5State(BOARD0, 'o', 'x');
        assertTrue(Arrays.deepEquals(BOARD0, state.getBoard()));
        assertEquals('o', state.getTurn());
        
        // now copy the state and see if it is what is expected
        TicTacToe5x5State copy = state.copy();
        assertTrue(Arrays.deepEquals(copy.getBoard(), state.getBoard()));
        assertEquals('o', copy.getTurn());

        // if the following test fails you need to make sure that your TicTacToe5x5State.copy
        // creates a copy of the state.  In particular, 2D arrays rows must be re-allocated
        // and each value copied individually to the new row, otherwise you will end up 
        // sharing a reference to the row in the original 2D array.
        TicTacToe5x5Piece[][] copyBoard = copy.getBoard();
        TicTacToe5x5Piece[][] stateBoard = state.getBoard();
        assertNotSame(copyBoard, stateBoard);
        for (int row = 0; row < stateBoard.length; row++) {
            assertNotSame(copyBoard[row], stateBoard[row]);
        }
    }

    
    public void test_isEnd() {
        TicTacToe5x5State board0 = new TicTacToe5x5State(BOARD0, 'x', 'o');
        TicTacToe5x5State board1 = new TicTacToe5x5State(BOARD1, 'x', 'o');
        TicTacToe5x5State board2 = new TicTacToe5x5State(BOARD2, 'x', 'o');
        TicTacToe5x5State board3 = new TicTacToe5x5State(BOARD3, 'x', 'o');
        TicTacToe5x5State board4 = new TicTacToe5x5State(BOARD4, 'x', 'o');

        assertFalse(board0.isEnd());
        assertFalse(board1.isEnd());
        assertFalse(board2.isEnd());
        assertTrue(board3.isEnd());
        assertTrue(board4.isEnd());
    }
    
   
   
    public void test_getHeuristicScore() {
        TicTacToe5x5State board0 = new TicTacToe5x5State(BOARD0, 'x', 'o');
        TicTacToe5x5State board1 = new TicTacToe5x5State(BOARD1, 'x', 'o');
        TicTacToe5x5State board2 = new TicTacToe5x5State(BOARD2, 'x', 'o');
        TicTacToe5x5State board3 = new TicTacToe5x5State(BOARD3, 'x', 'o');
        TicTacToe5x5State board4 = new TicTacToe5x5State(BOARD4, 'x', 'o');

        TicTacToe5x5AI aiX = new TicTacToe5x5AI('x');
        TicTacToe5x5AI aiO = new TicTacToe5x5AI('o');
        
        assertEquals(0.0, aiX.getHeuristicScore(board0), 0.01);
        assertEquals(0.0, aiO.getHeuristicScore(board0), 0.01);
        assertEquals(1.0, aiX.getHeuristicScore(board1), 0.01);
        assertEquals(2.0, aiO.getHeuristicScore(board1), 0.01);
        assertEquals(2.0, aiX.getHeuristicScore(board2), 0.01);
        assertEquals(3.0, aiO.getHeuristicScore(board2), 0.01);
        assertEquals(4.0, aiX.getHeuristicScore(board3), 0.01);
        assertEquals(3.0, aiO.getHeuristicScore(board3), 0.01);
        assertEquals(3.0, aiX.getHeuristicScore(board4), 0.01);
        assertEquals(3.0, aiO.getHeuristicScore(board4), 0.01);
    }
    
    // this is the first test for DL2 that you need to make work
    public void test_changeTurn() {
        TicTacToe5x5State state = new TicTacToe5x5State(BOARD0, 'o', 'x');
        state.changeTurn();
        assertEquals('x', state.getTurn());
        assertEquals('o', state.getNotTurn());
    }
    
    public void test_TicTacToe5x5Move() {
        TicTacToe5x5Move move1 = new TicTacToe5x5Move(3, 0);
        TicTacToe5x5Move move2 = new TicTacToe5x5Move(2, 2);
        
        // use the initial state from TicTacToe5x5
        TicTacToe5x5State state0 = new TicTacToe5x5State(BOARD0, 'o', 'x');
        assertTrue(move1.isValid(state0));
        assertFalse(move2.isValid(state0)); // middle square is not usable by either player
        
        TicTacToe5x5State state1 = new TicTacToe5x5State(BOARD1, 'o', 'x');
        assertFalse(move1.isValid(state1)); // square 3, 0 already has a value in it
        
        TicTacToe5x5State after = state0.copy();
        move1.make(after);
        assertEquals('x', after.getTurn());
        TicTacToe5x5Piece[][] expectedBoard = 
            {{E, E, E, E, E},
             {E, E, E, E, E},
             {E, E, B, E, E},
             {O, E, E, E, E},
             {E, E, E, E, E}};
        
        assertTrue(Arrays.deepEquals(expectedBoard, after.getBoard()));
        
        // if the following test fails then your state.copy method probably still has a problem and is
        // sharing a reference for the data
        expectedBoard = 
            new TicTacToe5x5Piece[][]{{E, E, E, E, E},
                         {E, E, E, E, E},
                         {E, E, B, E, E},
                         {E, E, E, E, E},
                         {E, E, E, E, E}};
        
        assertTrue(Arrays.deepEquals(expectedBoard, state0.getBoard()));
    }
    
    
    public void test_TicTacToe5x5AI_getAllValidMoves() {
        TicTacToe5x5AI ai = new TicTacToe5x5AI('o');
        TicTacToe5x5State state = new TicTacToe5x5State(BOARD0, 'o', 'x');
        
        List<TicTacToe5x5Move> moves = ai.getAllValidMoves(state);
        // check to make sure at least all empty space moves are in there
        int missingMoves = 0;
        for (int i = 0; i < 5; i++) {
            for (int j = 0; j < 5; j++) {
                if (BOARD0[i][j] instanceof TicTacToe5x5EmptyPiece) {
                    boolean found = false;
                    for (TicTacToe5x5Move move : moves) {
                        if (move.getRow() == i && move.getColumn() == j) {
                            found = true;
                        }
                    }
                    if (!found) {
                        missingMoves++;
                    }
                }
            }
        }
        assertEquals(0, missingMoves); // should be 0 missing moves
    }
    
    public void test_AIPlayer_getNextMove() {
        // check to see if on board 2 they will make the move that will win the game
        TicTacToe5x5AI ai = new TicTacToe5x5AI('x');
        TicTacToe5x5State state = new TicTacToe5x5State(BOARD2, 'x', 'o');
        
        TicTacToe5x5Move move = ai.getNextMove(state);
        assertEquals(2, move.getRow());
        assertEquals(0, move.getColumn());
    }
    
    public static void main(String[] args) {
        // print the state
        TicTacToe5x5State board0 = new TicTacToe5x5State(BOARD0, 'x', 'o');
        TicTacToe5x5State board1 = new TicTacToe5x5State(BOARD1, 'x', 'o');
        TicTacToe5x5State board2 = new TicTacToe5x5State(BOARD2, 'x', 'o');
        TicTacToe5x5State board3 = new TicTacToe5x5State(BOARD3, 'x', 'o');
        TicTacToe5x5State board4 = new TicTacToe5x5State(BOARD4, 'x', 'o');
        
        System.out.println(board0.toString());
        System.out.println(board1.toString());
        System.out.println(board2.toString());
        System.out.println(board3.toString());
        System.out.println(board4.toString());
    }
}
