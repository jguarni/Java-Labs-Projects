package edu.udel.jatlas.tictactoe.android;

/**
 * Represents a RxC grid where lines are evenly spaced across the 2x2x2 world coordinates
 * in the X/Y plane (Z=0).  Lines are placed at the edges as well.
 * 
 * @author jatlas
 *
 */
public class Grid extends Model3d {
    /**
     * A RxC Grid is going to be made up of R+C+2 grid "lines" total.
     * Each line is actually two triangles (4 vertices) as it is a thin
     * rectangle.
     */
    private static final float[] generateVertices(int rows, int columns, float lineWidth) {
        // all of the horizontal lines
        float[] vertices = new float[(rows+columns+2)*4*3]; // 4 vertices per line, 3 coordinates per vertex
        float h = lineWidth / 2f; // half line width
        float perRow = 2.0f / rows;
        float perColumn = 2.0f / columns;
        float min = -1f - h;
        float max = 1f + h;
        int v = 0;
        for (int r = 0; r <= rows; r++) {
            float rc = r * perRow - 1f; // center of row
            // 4 vertices, declared counter-clockwise
            
            // upper left
            vertices[v++] = min;  // x
            vertices[v++] = rc+h; // y
            vertices[v++] = 0f;   // z
            // lower left
            vertices[v++] = min;  // x
            vertices[v++] = rc-h; // y
            vertices[v++] = 0f;   // z
            // lower right
            vertices[v++] = max;  // x
            vertices[v++] = rc-h; // y
            vertices[v++] = 0f;   // z
            // upper right
            vertices[v++] = max;  // x
            vertices[v++] = rc+h; // y
            vertices[v++] = 0f;   // z
        }
        for (int c = 0; c <= columns; c++) {
            float cc = c * perColumn - 1f; // center of column
            // 4 vertices, declared counter-clockwise
            
            // upper left
            vertices[v++] = cc-h; // x
            vertices[v++] = max;  // y
            vertices[v++] = 0f;   // z
            // lower left
            vertices[v++] = cc-h; // x
            vertices[v++] = min;  // y
            vertices[v++] = 0f;   // z
            // lower right
            vertices[v++] = cc+h; // x
            vertices[v++] = min;  // y
            vertices[v++] = 0f;   // z
            // upper right
            vertices[v++] = cc+h; // x
            vertices[v++] = max;  // y
            vertices[v++] = 0f;   // z
        }
        
        return vertices;
    }
    
    private static final short[] generateTriangles(int rows, int columns) {
        // all of the horizontal lines
        short[] indices = new short[(rows+columns+2)*2*3]; // 2 triangles per "line", 3 vertices per triangle
        int v = 0;
        int i = 0;
        int total = rows+columns+2;
        for (int t = 0; t < total; t++) {
            // 2 triangles, declared counter-clockwise
            indices[i++] = (short)(v);
            indices[i++] = (short)(v+1);
            indices[i++] = (short)(v+2);
            indices[i++] = (short)(v+2);
            indices[i++] = (short)(v+3);
            indices[i++] = (short)(v);
            
            v += 4; // each line used 4 vertices
        }
        
        return indices;
    }
    
    public Grid(int rows, int columns, float lineWidth, float[] color) {
        super(generateVertices(rows, columns, lineWidth),
              generateTriangles(rows, columns),
              new float[][]{color});
    }
}
