/** Automatically generated file. DO NOT MODIFY */
package edu.udel.jguarni.app.blockevader;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}