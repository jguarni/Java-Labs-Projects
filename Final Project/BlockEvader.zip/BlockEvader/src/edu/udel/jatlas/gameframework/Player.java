package edu.udel.jatlas.gameframework;

public interface Player<M extends Move<S>, S extends State<S>> {
    public M getNextMove(S state);
    public String getIdentifier();
}
