package edu.udel.jguarni.blockevader;

import edu.udel.jatlas.gameframework.Position;
import edu.udel.jguarni.blockevader.EvaderState;

// This class will create an Evader object. The evader is the object that is avoiding the blocks that are onward towards it. The evader
// has a color, width, length, and a postion that is defined by its row and column.

public class Evader extends Piece<Evader> {

	private int direction;

	public Evader(Position position, int direction) {
		super(position);
		this.direction = direction;
	}

	// Setters and Getters

	public int getDirection() {
		return direction;
	}

	public void setDirection(int direction) {
		this.direction = direction;
	}

	public Evader copy() {
		return new Evader(position, direction);
	}

	public Position getPosition() {
		return position;
	}

	public void setPosition(Position position) {
		this.position = position;
	}

	public Position getNextPosition() {
		Position next = this.getPosition();

		if (direction == UP) {
			next = new Position(this.getPosition().getRow() - 1, this
					.getPosition().getCol());

		} else if (direction == DOWN) {
			next = new Position(this.getPosition().getRow() + 1, this
					.getPosition().getCol());
		}

		return next;
	}


    
    
	public void onTick(EvaderState state) {
		// if direction is up then switch to down
		// if direction is down then move position down and set direction to still
		// if direction is still do nothing
		Evader evader = state.getEvader();
		
		if((evader.getDirection() == DOWN) && (evader.getPosition().getRow() == 3)) {
		}
		if (evader.getDirection() == DOWN) {
			evader.setPosition(new Position(3,2));
			evader.setDirection(STILL);
		}
		
		if (evader.getDirection() == UP) {
			evader.setDirection(DOWN);
		}
		
		if(evader.getDirection() == STILL){
		}
	}
	
}
