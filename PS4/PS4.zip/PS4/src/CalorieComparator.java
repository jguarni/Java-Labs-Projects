import java.util.Comparator;

public class CalorieComparator implements Comparator<Object>, Edible {

	public CalorieComparator() {
	};

	@Override
	//Compares calories of two edible objects to determine which one has more, less or equal to each other.
	public int compare(Object o1, Object o2) {
		if (((Edible) o1).getCalories() < ((Edible) o2).getCalories()) {
			return -1;
		} else if (((Edible) o1).getCalories() > ((Edible) o2).getCalories()) {
			return 1;

		}
		return 0;
	}
	
	@Override
	//Gets calories for an edible object.
	public double getCalories() {

		return 0;
	}

}
