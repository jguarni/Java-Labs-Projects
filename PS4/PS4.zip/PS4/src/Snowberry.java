public class Snowberry extends Fruit {
	//Creates a new instance of a snowberry. A snowberry has a fixed white color and weight of 0.117.
	public Snowberry() {
		super("White", 0.117);
	}
	//A method to calculate the number of calories in a snowberry.
	public double getCalories() {
		return 1;
	}
}
