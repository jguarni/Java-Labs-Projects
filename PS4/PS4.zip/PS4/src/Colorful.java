import java.util.List;

//An interface to determine if an object is colorful.
public interface Colorful{

	public List<Colorful> getColorfulItems();
}
