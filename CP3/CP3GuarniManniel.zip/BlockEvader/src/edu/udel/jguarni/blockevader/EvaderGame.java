package edu.udel.jguarni.blockevader;

import java.util.List;
import java.util.ArrayList;
import java.util.Arrays;

import edu.udel.jatlas.gameframework.ConsoleTickManager;
import edu.udel.jatlas.gameframework.Game;
import edu.udel.jatlas.gameframework.Position;

public class EvaderGame extends Game<EvaderMove, EvaderState> {
	
	static List<Block> Blocklist = new ArrayList<Block>((Arrays.asList(new Block(
			new Position(2, 4), 1), new Block(new Position(2, 6), 1),
			new Block(new Position(3, 8), 1), new Block(
					new Position(3, 10), 1), new Block(new Position(3, 12),
					1), new Block(new Position(2, 15), 1), new Block(
					new Position(3, 17), 1))));
	static EvaderState start = new EvaderState(Blocklist, new Evader(
			new Position(3, 2), 0), 1000, 0, 5, 20, 0);
	public EvaderGame(EvaderState currentState) {
		super(currentState);
	}
    public EvaderGame() {
        this(start);
    }
    
    

	public void onTick() {
		super.onTick();
		EvaderState currentState = getCurrentState();
		currentState.getEvader().onTick(currentState);

		for (Block p : currentState.getBlock()) {
			p.onTick(currentState);
		}
		if (Math.random() >= 0.5) {
			currentState.getBlock().add(
					new Block(new Position((int) (Math.random() * 2  + 2), 18), 1));
		}
		if (currentState.getBlock().get(0).getPosition().getCol() == 0) {
			currentState.getBlock().remove(0);
		}

	}

	public String toString() {
		return getCurrentState().toString();
	}

	public static void main(String[] args) {
		List<Block> Blocklist = new ArrayList<Block>((Arrays.asList(new Block(
				new Position(2, 4), 1), new Block(new Position(2, 6), 1),
				new Block(new Position(3, 8), 1), new Block(
						new Position(3, 10), 1), new Block(new Position(3, 12),
						1), new Block(new Position(2, 15), 1), new Block(
						new Position(3, 17), 1))));
		
		EvaderState start = new EvaderState(Blocklist, new Evader(
				new Position(3, 2), 0), 1000, 0, 5, 20, 0);

		EvaderGame game = new EvaderGame(start);
		game.addPlayer(new EvaderAIPlayer());
		ConsoleTickManager.manageGame(game);
	}

    public void stop() {
        
    }
    

	public void start() {
		// TODO Auto-generated method stub
		
	}

	public void nextLevel() {
		// TODO Auto-generated method stub
		
	}

}
