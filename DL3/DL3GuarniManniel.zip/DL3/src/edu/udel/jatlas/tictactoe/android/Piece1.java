package edu.udel.jatlas.tictactoe.android;

public class Piece1 extends Model3d {

    private static final float[] squareVertices(float sideLength) {
        float halfSideLength = sideLength/2f;
        float qSideLength = halfSideLength/1.2f;
        float[] vertices = new float[]{
                     qSideLength,  halfSideLength, 0.0f,  // 0, Top Left
                     halfSideLength,  qSideLength, 0.0f,  // 1, Bottom Left
                     halfSideLength, -qSideLength, 0.0f,    // 2, 
                     qSideLength,  -halfSideLength, 0.0f,  // 3, Bottom Right
        			 -qSideLength, -halfSideLength, 0.0f,    // 4,
        			 -halfSideLength,  -qSideLength, 0.0f, // 5,
        			 -halfSideLength, qSideLength, 0.0f,   // 6,
        			 -qSideLength,  halfSideLength, 0.0f,}; // 7, 

        return vertices;
    }
    
    
    public Piece1(float sideLength, float[] color) {
        super(squareVertices(sideLength),
        	  new short[]{ 0,4,5,0,1,4,2,3,7,6,7,3}, // the two triangles, counter-clockwise
              new float[][]{color});
    }

}
