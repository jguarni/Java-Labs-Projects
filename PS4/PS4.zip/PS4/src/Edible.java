//An interface to tell if an object is edible.
public interface Edible{
	
	//A method to calculate the calories in an edible object.
	public double getCalories();

}
