package edu.udel.jguarni.blockevader;

public class ChangeDirectionMove extends EvaderMove {
    private int direction;

    public ChangeDirectionMove(int direction) {
    	super(direction);
        this.direction = direction;
    }

    public boolean isValid(EvaderState state) {
        return false;
    }

    public void make(EvaderState state) {
        state.getEvader().setDirection(direction);
    }
    
    public int getDirection() {
        return direction;
    }

    public String toString() {
        return "ChangeDirectionMove [direction=" + direction + "]";
    }
}
