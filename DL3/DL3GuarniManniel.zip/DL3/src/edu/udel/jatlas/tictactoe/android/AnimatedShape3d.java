package edu.udel.jatlas.tictactoe.android;

import javax.microedition.khronos.opengles.GL10;

// DL3 Created by Joe Guarni and Peter Manniel

public class AnimatedShape3d extends Shape3d {
	
	private long currenttime;

	public AnimatedShape3d(Model3d model) {
		super(model);
		this.currenttime = System.currentTimeMillis(); //Sets the current time to the system time.
	}

	public void draw(GL10 gl) {
		long elapsed = System.currentTimeMillis() - this.currenttime; //computes elapsed time
		float distance = 2.0f - getZ(); //computes distance for rotation
		float set = 0;
		setRotation(0, 0, 0);
		if (this.getZ() > 0) { 
			if (getZ() - elapsed / 1000.0f > 0)  {          //checks if the z - elapsed time is valid
				set = (getZ() - elapsed / 1000.0f);
			}

			setPosition(getX(), getY(), set); //Sets the positon
			setRotation(0, distance * 720/2, 0); //Sets the rotation
		}
		this.currenttime = System.currentTimeMillis(); //Sets the current time to the current draw call
		super.draw(gl); //draws the object
	}
}
