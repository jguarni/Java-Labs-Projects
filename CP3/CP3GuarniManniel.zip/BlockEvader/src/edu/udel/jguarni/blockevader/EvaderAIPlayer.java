package edu.udel.jguarni.blockevader;

import java.util.ArrayList;
import java.util.List;

import edu.udel.jatlas.gameframework.AIPlayer;
import edu.udel.jatlas.gameframework.Position;

import edu.udel.jguarni.blockevader.ChangeDirectionMove;
import edu.udel.jguarni.blockevader.Evader;
import edu.udel.jguarni.blockevader.EvaderMove;
import edu.udel.jguarni.blockevader.EvaderState;

public class EvaderAIPlayer extends AIPlayer<EvaderMove, EvaderState> {
	public EvaderAIPlayer() {
		super();
	}

	@Override
	public String getIdentifier() {
	
		return null;
	}

	@Override
	public List<EvaderMove> getAllValidMoves(EvaderState state) {
		List<EvaderMove> validMoves = new ArrayList<EvaderMove>();

		// well a valid move is anything in Snake
		// (might not be a *good* move though, as you could die on the next
		// tick)
		validMoves.add(new ChangeDirectionMove(Evader.DOWN));
		validMoves.add(new ChangeDirectionMove(Evader.UP));
		validMoves.add(new ChangeDirectionMove(Evader.STILL));

		return validMoves;
	}

	@Override
	public double getHeuristicScore(EvaderState state) {
		Evader evader = state.getEvader();
		Position evaderpos = evader.getPosition();
		
		Position nextPosition = Piece.next(evaderpos, evader.getDirection());
		if (!state.isValid(nextPosition)){
			nextPosition = evaderpos;
		}
		if (state.isEnd()){
			return -1;
		}
		return 0;
	}

}
