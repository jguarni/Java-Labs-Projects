package edu.udel.jatlas.tictactoe;

import edu.udel.jatlas.gameframework.LinearIterator;
import edu.udel.jatlas.gameframework.SequenceMatch;
import edu.udel.jatlas.gameframework.State;

public class TicTacToe5x5State implements State<TicTacToe5x5State> {
    private TicTacToe5x5Piece[][] board;
    private char turn;
    private char notTurn;
    
    public TicTacToe5x5State(char turn, char notTurn) {
        // creates a default board
        TicTacToe5x5Piece E = new TicTacToe5x5EmptyPiece();
        TicTacToe5x5Piece B = new TicTacToe5x5BlockedPiece();
        
        this.board = new TicTacToe5x5Piece[][]
                {{E, E, E, E, E},
                 {E, E, E, E, E},
                 {E, E, B, E, E},
                 {E, E, E, E, E},
                 {E, E, E, E, E}};
        this.turn = turn;
        this.notTurn = notTurn;
    }
    
    public TicTacToe5x5State(TicTacToe5x5Piece[][] board, char turn, char notTurn) {
        this.board = board;
        this.turn = turn;
        this.notTurn = notTurn;
    }

    public TicTacToe5x5Piece[][] getBoard() {
        return board;
    }

    public char getTurn() {
        return turn;
    }

    public char getNotTurn() {
        return notTurn;
    }
    
    /**
     * Swaps the current turn with the notTurn
     */
    public void changeTurn() {
        char current = turn;
        turn = notTurn;
        notTurn = current;
    }

    /**
     * Returns a "visual" representation of a TicTacToe5x5 board
     */
    public String toString() {
        StringBuilder buffer = new StringBuilder();
        buffer.append("Player " + turn + "'s turn\n");
        for (int i = 0; i < board.length; i++) {
            for (int j = 0; j < board.length; j++) {
                buffer.append(board[i][j]);
            }
            buffer.append("\n");
        }
        return buffer.toString();
    }
    
    /**
     * Helper method that determines if the player with the
     * given symbol has won (got 4 in a row)
     */
    public boolean isWinner(char symbol) {
        return getMaxSequenceAnyDirection(new TicTacToe5x5Piece(symbol)) >= 4;
    }
    
    /**
     * Determines if the state is an end state (i.e. no further moves can be
     * made). For TicTacToe this method returns true if there are no empty
     * spaces on the board or if either player has won.
     * 
     * @return
     */
    public boolean isEnd() {
        if (isWinner(turn) || isWinner(notTurn)) {
            return true;
        }
        boolean emptySpace = false;
        for (TicTacToe5x5Piece[] row : board) {
            for (TicTacToe5x5Piece value : row) {
                if (value instanceof TicTacToe5x5EmptyPiece) {
                    emptySpace = true;
                }
            }
        }
        return !emptySpace;
    }
    
    /**
     * Returns the max sequence match along any row, column, or diagonal
     * of the occurrences of piece.
     */
    public int getMaxSequenceAnyDirection(TicTacToe5x5Piece piece) {
        TicTacToe5x5Piece[][] board = getBoard();
        LinearIterator<TicTacToe5x5Piece> iter = new LinearIterator<TicTacToe5x5Piece>(board);
        int maxSequence = 0;

        // this assumes a square matrix board
        for (int i = 0; i < board.length; i++) {
            // check row
            iter.reset(i, 0, 0, 1);
            maxSequence = Math.max(maxSequence, SequenceMatch.max(iter, piece));
            // check col
            iter.reset(0, i, 1, 0);
            maxSequence = Math.max(maxSequence, SequenceMatch.max(iter, piece));
            // check left->right diags
            iter.reset(0, i, 1, 1);
            maxSequence = Math.max(maxSequence, SequenceMatch.max(iter, piece));
            iter.reset(i, 0, 1, 1);
            maxSequence = Math.max(maxSequence, SequenceMatch.max(iter, piece));
            // check right->left diags
            iter.reset(0, i, 1, -1);
            maxSequence = Math.max(maxSequence, SequenceMatch.max(iter, piece));
            iter.reset(i, board.length-1, 1, -1);
            maxSequence = Math.max(maxSequence, SequenceMatch.max(iter, piece));
        }
    
        return maxSequence;
    }

    

    public TicTacToe5x5State copy() {
        TicTacToe5x5Piece[][] newboard = new TicTacToe5x5Piece[5][5];
        for (int row = 0; row < newboard.length; row++) {
            for (int col = 0; col < newboard[row].length; col++) {
                // the copying of the reference here is okay since all
                // TicTacToe5x5Pieces are immutable.  If one of them
                // allowed mutation, we would need to create a copy
                // of the piece itself.
                newboard[row][col] = board[row][col];
            }
        }
        return new TicTacToe5x5State(newboard, turn, notTurn);
    }
    
    
}
