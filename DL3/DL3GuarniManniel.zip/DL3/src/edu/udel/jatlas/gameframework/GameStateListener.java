package edu.udel.jatlas.gameframework;


public interface GameStateListener {
    public void onStateChange(Object game);
}
