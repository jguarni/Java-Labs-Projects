package edu.udel.jatlas.tictactoe.android;

import android.widget.TextView;
import edu.udel.jatlas.gameframework.GameStateListener;
import edu.udel.jatlas.gameframework.Player;
import edu.udel.jatlas.tictactoe.TicTacToe5x5Game;
import edu.udel.jatlas.tictactoe.TicTacToe5x5Move;
import edu.udel.jatlas.tictactoe.TicTacToe5x5State;

public class Scoreboard extends TextView implements GameStateListener {
    private TicTacToe5x5Activity activity;
    
    public Scoreboard(TicTacToe5x5Activity context) {
        super(context);
        activity = context;
    }
    
    /**
     * The scoreboard text will display the current player
     * whose move it is during the game.  When the game has completed it will
     * show the winner or draw, and a short instruction on how to play again.
     */
    public void onStateChange(Object o) {
        if (o == activity.getCurrentGame()) {
            TicTacToe5x5Game game = activity.getCurrentGame();
            TicTacToe5x5State state = activity.getCurrentGame().getCurrentState();
            String message;
            if (state.isEnd()) {
                Player<TicTacToe5x5Move, TicTacToe5x5State> winner = game.getWinner();
                if (winner == null) {
                    message = "Draw Game. Touch to play again.";
                }
                else {
                    message = "Player " + winner.toString() + " wins! Touch to play again.";
                }
            }
            else {
                message = "Player " + game.getCurrentState().getTurn() + "'s turn.";
            }
            setText(message);
        }
    }

}
