package edu.udel.jatlas.gameframework;

import java.util.Iterator;

@SuppressWarnings(value = "rawtypes")
public class SequenceMatch {
	
	/**
	 * Finds the max sequence in the Iterator where the item is equal to the
	 * given value.
	 * 
	 * @param sequence
	 * @return
	 */
	public static int max(Iterator sequence, Object value) {
		int score = 0;
        int max_score = 0;
        while (sequence.hasNext()) {
        	Object o = sequence.next();
            if (!value.equals(o)) {
                max_score = Math.max(max_score, score);
                score = 0;
            }
            else {
                score++;
            }
        }
        return Math.max(score, max_score);
	}
}
