package edu.udel.jguarni.blockevader;

import java.awt.Color;
//This class will create the test cases for BlockEvader. It shows a beginning state, two mid game states, and an end game state. It
//will then print the different states by displaying a grid with the character postions on it. It will also display the current checkpoint
// and the current score.

public class EvaderTests {
	private static Block[] beginblock = {new Block(2,2,Color.BLACK,"Ground",3,5),new Block(2,2,Color.BLACK,"Air",2,7),new Block(2,2,Color.BLACK,"Air",2,9)
	,new Block(2,2,Color.BLACK,"Ground",3,11),new Block(2,2,Color.BLACK,"Ground",3,13),new Block(2,2,Color.BLACK,"Ground",3,15),new Block(2,2,Color.BLACK,"Air",2,18)};
	
	private static Block[] midblock = {new Block(2,2,Color.BLACK,"Ground",3,2),new Block(2,2,Color.BLACK,"Air",2,4),new Block(2,2,Color.BLACK,"Air",2,6)
	,new Block(2,2,Color.BLACK,"Ground",3,8),new Block(2,2,Color.BLACK,"Ground",3,10),new Block(2,2,Color.BLACK,"Ground",3,12),new Block(2,2,Color.BLACK,"Air",2,15), new Block(2,2, Color.BLACK, "Ground", 3,17)};
	
	private static Block[] midblock2 = {new Block(2,2,Color.BLACK,"Air",2,2),new Block(2,2,Color.BLACK,"Air",2,4),new Block(2,2,Color.BLACK,"Ground",3,6)
	,new Block(2,2,Color.BLACK,"Ground",3,8),new Block(2,2,Color.BLACK,"Ground",3,10),new Block(2,2,Color.BLACK,"Air",2,13),new Block(2,2,Color.BLACK,"Ground",3,15),new Block(2,2,Color.BLACK,"Ground",3,17)};
	
	private static Block[] endblock = {new Block(2,2,Color.BLACK,"Ground",3,2),new Block(2,2,Color.BLACK,"Ground",3,4),new Block(2,2,Color.BLACK,"Air",3,6)
	,new Block(2,2,Color.BLACK,"Air",2,8),new Block(2,2,Color.BLACK,"Air",2,10),new Block(2,2,Color.BLACK,"Ground",2,12),new Block(2,2,Color.BLACK,"Ground",3,14),new Block(2,2,Color.BLACK,"Ground",3,16)};
	
	
	private static Evader beginevader = new Evader(Color.RED,4,4,3,2);
	private static Evader midevader = new Evader(Color.RED,4,4,2,2);
	private static Evader midevader2 = new Evader(Color.RED,4,4,3,2);
	
	private static EvaderState beginstate = new EvaderState(beginblock,beginevader,200,0,0,5,20);
	private static EvaderState midstate = new EvaderState(midblock, midevader,300,20,1,5,20);
	private static EvaderState midstate2 = new EvaderState(midblock2, midevader2,300,21,1,5,20);
	private static EvaderState endstate = new EvaderState(endblock, beginevader,400,40,2,5,20);

	
	public static void main(String[] args) {
		System.out.println("\nThese tests show the different states of BlockEvader.\nThe letter E expresses the position of the evader.\nThe number 0 expresses the position of a block.\nThe special" +
				" character # expresses when the evader loses a life and there is a collision.\n");
		System.out.println(beginstate);
		System.out.println(midstate);
		System.out.println(midstate2);
		System.out.println(endstate);
		
	}

}
