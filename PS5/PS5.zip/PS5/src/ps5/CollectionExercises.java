package ps5;

import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public class CollectionExercises {

	/**
	 * Returns a new List that contains all of the Integers in the given List
	 * that are less than zero
	 */

	public static List<Integer> lessThanZero(List<Integer> l) {
		Iterator<Integer> itr = l.iterator();
		Iterator<Integer> itr2 = l.iterator();

		int count = 0;
		int count2 = 0;

		while (itr.hasNext()) {
			int x = itr.next();

			if (x < 0) {
				count++;
			}
		}
		Integer[] newArray = new Integer[count];

		while (itr2.hasNext()) {
			int y = itr2.next();

			if (y < 0) {
				newArray[count2] = y;
				count2++;
			}
		}

		List<Integer> nlist = Arrays.asList(newArray);
		return nlist;
	}

	/**
	 * Mutates the given List by removing all of the Integers in the List that
	 * are less than zero
	 * @return 
	 */
	public static List<Integer> removeLessThanZero(List<Integer> l) {
		Iterator<Integer> itr = l.iterator();
		
		while (itr.hasNext()) {
			int x = itr.next();

			if (x < 0) {
				itr.remove();
			}
		}
		return l;
	}

	/**
	 * Returns a new Set that contains all of the elements in a and all of the
	 * elements in b (i.e. the union of two sets).
	 */

	public static Set<Integer> union(Set<Integer> a, Set<Integer> b) {
		Set<Integer> c = new HashSet<Integer>();
		c.addAll(a);
		c.addAll(b);
		return c;
	}

	/**
	 * Returns a new Set that contains all of the elements that are in a and
	 * also in b (i.e. the intersection of two sets).
	 */
	public static Set<Integer> intersection(Set<Integer> a, Set<Integer> b) {
		Set<Integer> c = new HashSet<Integer>();
		for (int ele : a) {
			if (b.contains(ele)) {
				c.add(ele);
			}
		}
		return c;
	}

	/**
	 * Returns a new Set that contains all of the elements in a that are not in
	 * b (i.e. the difference of a from b, or a subtract b).
	 */
	public static Set<Integer> difference(Set<Integer> a, Set<Integer> b) {
		Set<Integer> c = new HashSet<Integer>();
		for (int ele : a) {
			if (b.contains(ele) == false) {
				c.add(ele);
			}
		}
		return c;
	}

	/**
	 * Returns a new Map that contains a reverse mapping of the given map. Thus
	 * each key in the given map will appear as a value in the result, and each
	 * value in the given map will appear as a key in the result.
	 * 
	 * Because a Map contains a many to one mapping (i.e. two keys can map to
	 * the same value), to properly return a reverse mapping each key in the
	 * result could have multiple values. To represent this, each key in the
	 * result has a Set as its mapped value where the Set contains all of the
	 * multiple values.
	 * 
	 * See the test class for a concrete example.
	 */
	public static Map<String, Set<String>> reverseMapping(
			Map<String, String> mapping) {
		
		Map<String, Set<String>> reverse = new HashMap<String,Set<String>>();
		for (Entry<String, String> i : mapping.entrySet()){
			if (reverse.containsValue(mapping.values()) == false) {
				reverse.put(i.getValue(), null);
			}
		}
		for (Entry<String, Set<String>> j : reverse.entrySet()){
			Set<String> temp = new HashSet<String>();
			for (Entry<String, String> i : mapping.entrySet()){
				if (j.getKey() == i.getValue()) {
					temp.add(i.getKey());
					
			}
			reverse.put(j.getKey(),temp);

	    }
		}
		return reverse;
	}

}

