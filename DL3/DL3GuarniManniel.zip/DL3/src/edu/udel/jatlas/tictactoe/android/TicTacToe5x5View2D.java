package edu.udel.jatlas.tictactoe.android;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Paint.Style;
import android.view.View;
import edu.udel.jatlas.gameframework.GameStateListener;
import edu.udel.jatlas.tictactoe.TicTacToe5x5Piece;

/**
 * This view extends the basic android.view.View to provide implementations for
 * drawing directly to the Canvas.
 * 
 * @author jatlas
 *
 */
public class TicTacToe5x5View2D extends View implements GameStateListener {
    // the activity
    protected TicTacToe5x5Activity activity;

    // the width and height of the current game view
    private int width;
    private int height;
    
    // the scale of the game board grid, how many pixels per col (x) and row (y)
    private float scale_x;
    private float scale_y;

    
    public TicTacToe5x5View2D(TicTacToe5x5Activity context) {
        super(context);
        activity = context;
        
        setFocusable(true);
        setFocusableInTouchMode(true);
    }

    /**
     * Provides specific implementation for a TicTacToe5x5View.  This view has 3 main components:
     *   - a grid
     *   - a set of pieces
     */
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        
        drawGrid(canvas);
        drawPieces(canvas);
    }
    
    /**
     * Draws a 5x5 grid with the middle square filled in.
     * 
     * @param canvas
     */
    protected void drawGrid(Canvas canvas) {
        Paint gridPaint = new Paint();
        gridPaint.setColor(Color.WHITE);
        gridPaint.setStrokeWidth(4); // the "weight" of the lines
        gridPaint.setStyle(Style.FILL_AND_STROKE);
        
        // draw horizontal lines for each row
        TicTacToe5x5Piece[][] board = activity.getCurrentGame().getCurrentState().getBoard();
        for (int i = 0; i <= board.length; i++) {
            canvas.drawLine(0, i*scale_y, width, i*scale_y, gridPaint);
        }
        // draw vertical lines for each row
        for (int i = 0; i <= board.length; i++) {
            canvas.drawLine(i*scale_x, 0, i*scale_x, height, gridPaint);
        }
        
        // draw filled middle square
        canvas.drawRect(scale_x*2, scale_y*2, scale_x*3-1, scale_y*3-1, gridPaint);   
    }
    
    /**
     * Draws all of the pieces represented by the current game state.
     * Calls a separate method to draw each x and o by computing the correct upper left
     * corner x and y position and passing these into the other methods.
     * 
     * @param canvas
     */
    protected void drawPieces(Canvas canvas) {
        // creating one Paint object for all x's
        Paint pieceXPaint = new Paint();
        pieceXPaint.setColor(Color.RED);
        pieceXPaint.setStrokeWidth(8);
        pieceXPaint.setStyle(Style.STROKE);
        
        // creating one Paint object for all o's
        Paint pieceOPaint = new Paint();
        pieceOPaint.setColor(Color.GREEN);
        pieceOPaint.setStrokeWidth(8);
        pieceOPaint.setStyle(Style.STROKE);
        
        TicTacToe5x5Piece[][] board = activity.getCurrentGame().getCurrentState().getBoard();

        // loop through each position in the game state
        for (int row = 0; row < board.length; row++) {
            for (int col = 0; col < board[row].length; col++) {
                if (board[row][col].getSymbol() == 'x') {
                    drawX(col*scale_x, row*scale_y, canvas, pieceXPaint);
                }
                else if (board[row][col].getSymbol() == 'o') {
                    drawO(col*scale_x, row*scale_y, canvas, pieceOPaint);
                }
            }
        }
    }
    
    /**
     * Draws an X at a square given the x,y position of the upper left corner of the square.
     * Uses a 5 pixel buffer so that the StrokeWidth of the lines does not cause the X
     * to write over the grid into the neighboring squares:
     * 
     * -----
     * |   |
     * | X |
     * |   |
     * -----
     * 
     * where each of the spaces above are 5 pixels in height and width.
     * 
     * @param posx
     * @param posy
     * @param canvas
     * @param paint
     */
    private void drawX(float posx, float posy, Canvas canvas, Paint paint) {
        float xheight = scale_y - 10; // 5 pixel buffer
        float xwidth = scale_x - 10;
        
        canvas.drawLine(posx + 5, posy + 5, posx + 5 + xwidth, posy + 5 + xheight, paint);
        canvas.drawLine(posx + 5 + xwidth, posy + 5, posx + 5, posy + 5 + xheight, paint);
    }

    /**
     * Draws an O at a square given the x,y position of the upper left corner of the square.
     * Uses a 5 pixel buffer so that the StrokeWidth of the lines does not cause the O
     * to write over the grid into the neighboring squares:
     * 
     * -----
     * |   |
     * | O |
     * |   |
     * -----
     * 
     * where each of the spaces above are 5 pixels in height and width.
     * 
     * @param posx
     * @param posy
     * @param canvas
     * @param paint
     */
    private void drawO(float posx, float posy, Canvas canvas, Paint paint) {
        float radius = Math.min(scale_y/2-5, scale_x/2-5); // 5 pixel buffer
        
        canvas.drawCircle(posx + scale_x/2, posy + scale_y/2, radius, paint);
        
    }
    
    /**
     * This method is called by the Android platform when the app window size changes.
     * We store the initial setting of these so that we can compute the exact locations
     * to draw the components of our View.
     */
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);

        width = w;
        height = h;
        
        updateScaling();
    }
    
    private void updateScaling() {
        if (activity.getCurrentGame() != null) {
            scale_x = (float)width / activity.getCurrentGame().getCurrentState().getBoard()[0].length;
            scale_y = (float)height / activity.getCurrentGame().getCurrentState().getBoard().length;
        }
    }

    
    
    /**
     * Tell Android to re draw the View when the game state changed.
     */
    public void onStateChange(Object game) {
        if (game == this.activity.getCurrentGame()) {
           invalidate();
        }
    }
}
