package edu.udel.jatlas.tictactoe.android;

public class Piece2 extends Model3d {

    private static final float[] squareVertices(float sideLength) {
        float halfSideLength = sideLength/2f;
        float[] vertices = new float[]{
                    0,  halfSideLength, 0.0f,  // 0, Top Left
                    halfSideLength, 0, 0.0f,  // 1, Bottom Left
                     0, -halfSideLength, 0.0f,
                     -halfSideLength,  0, 0.0f};  // 2, Bottom Right

        return vertices;
    }
    
    public Piece2(float sideLength, float[] color) {
        super(squareVertices(sideLength),
        	  new short[]{ 0, 1, 2, 2, 3, 0}, // the two triangles, counter-clockwise
              new float[][]{color});
    }

}
