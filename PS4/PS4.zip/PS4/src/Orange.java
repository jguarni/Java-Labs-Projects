import java.util.List;

//An orange is a fruit that is edible and colorful. It has a constant color orange and a specified weight.
public class Orange extends Fruit implements Edible, Colorful{
	
	//Creates an instance of an orange.
	public Orange(double weight) {
		super("Orange", weight);
		// TODO Auto-generated constructor stub
	}

	@Override
	//Calculates the amount of calories for an instance of an orange.
	public double getCalories() {
		// TODO Auto-generated method stub
		return this.getWeight() * 5;
	}

	@Override
	public List<Colorful> getColorfulItems() {
		// TODO Auto-generated method stub
		return null;
	}
}
