package ps5;

/**
 * A Pipeline represents a segment of pipe in some linear arrangement.
 * It has a length and diameters of the incoming and outgoing connectors.
 * It also can have a next Pipeline or the next Pipeline may be null which
 * indicates the end of the connected Pipeline.
 * 
 * This Pipeline class is considered to be self-referential 
 * (i.e. recursive) because it contains a reference to its own type 
 * as a property. This software pattern allows us to chain specific
 * logic recursively so that we rely on the structure of the data
 * itself rather than a general purpose data structure.
 */
public class Pipeline {
    private int length;
    private int inDiameter;
    private int outDiameter;
    private Pipeline next;

    public Pipeline(int length, int inDiameter, int outDiameter, Pipeline next) {
        this.length = length;
        this.inDiameter = inDiameter;
        this.outDiameter = outDiameter;
        this.next = next;
    }

    public Pipeline getNext() {
        return next;
    }
    
    public void setNext(Pipeline next) {
        this.next = next;
    }

    /**
     * Returns the total length of all Pipelines in the linked list.
     */
    public int getTotalLength() {
    	if (next == null) {
    		return this.length;
    	}
    	else {
    		return this.length + next.getTotalLength();
    	}
    }

    /**
     * Returns true if any Pipeline in the linked list has an
     * outDiameter that is not equal to its next Pipeline's inDiameter.
     */
    public boolean hasLeak() {
    	if (next == null){
    		return false;
    	}
    	else if (this.outDiameter != next.inDiameter) {
    		return true;
    	}
    	return next.hasLeak();
    }
    
    /**
     * Returns the maximum flow of any Pipeline in the linked list. The
     * maximum flow is equal to the minimum diameter, either incoming
     * or outgoing. 
     */
    public int getMaxFlow() {
    	if (next == null){
    		if (this.inDiameter < this.outDiameter) {
    			return this.inDiameter;
    		}
    		else {
    			return this.outDiameter;
    		}	
    	}
    	else if (this.inDiameter < next.inDiameter) {
    		return this.inDiameter;
    	}
    	else if (this.outDiameter < next.outDiameter) {
    		return this.outDiameter;
    	}
        return next.getMaxFlow(); // remove this line when you start
    }
}
