import junit.framework.TestCase;


public class TestRectangle extends TestCase {

	public void test_getArea() {
		Rectangle testRect = new Rectangle(5, 10);
		assertEquals(50, testRect.getArea(), 0.1);
	}

	public void test_getPerimeter() {
		Rectangle testRect = new Rectangle(5, 10);
		assertEquals(30, testRect.getPerimeter(), 0.1);
	}
	
	public void test_makeGoldenRectangle() {
		Rectangle testRect1 = Rectangle.makeGoldenRectangle(1.618);
		Rectangle testRect2 = Rectangle.makeGoldenRectangle(2.5);
		Rectangle testRect3 = Rectangle.makeGoldenRectangle(3.6);
		
		assertEquals(8.472, testRect1.getPerimeter(),0.1);
		assertEquals(13.09, testRect2.getPerimeter(),0.1);
		assertEquals(18.85, testRect3.getPerimeter(),0.1);
	}
}
