public class Banana extends Fruit implements Edible{
	// A bananna extends the fruit class and has a constant color yellow. In order to create
	// an instance of a bananna a weight must be provided.
	
	//Creates an instance of bananna.
	
	public Banana(double weight) {
		super("Yellow", weight);
		// TODO Auto-generated constructor stub
	}

	@Override
	//Gets the calories from an instance of a bananna
	public double getCalories() {
		return this.getWeight() * 10;
	}

}
