package edu.udel.jatlas.tictactoe;

/**
 * A blocked piece represented by a #
 * (nobody can move on top of it)
 * 
 * @author jatlas
 */
public class TicTacToe5x5BlockedPiece extends TicTacToe5x5Piece {
    public TicTacToe5x5BlockedPiece() {
        super('#');
    }
}
