package edu.udel.jguarni.blockevader;

import java.awt.Color;
// This class will create an Evader object. The evader is the object that is avoiding the blocks that are onward towards it. The evader
// has a color, width, length, and a postion that is defined by its row and column.

public class Evader {
	public Evader(Color color, int width, int length, int row, int column) {
		super();
		this.color = color;
		this.width = width;
		this.length = length;
		this.row = row;
		this.column = column;
	}
	//Setters and Getters
	public int getRow() {
		return row;
	}
	public void setRow(int row) {
		this.row = row;
	}
	public int getColumn() {
		return column;
	}
	public void setColumn(int column) {
		this.column = column;
	}
	@Override
	public String toString() {
		return "Evader [color=" + color + ", width=" + width + ", length="
				+ length + "]";
	}
	public Color getColor() {
		return color;
	}
	public void setColor(Color color) {
		this.color = color;
	}
	public int getWidth() {
		return width;
	}
	public void setWidth(int width) {
		this.width = width;
	}
	public int getLength() {
		return length;
	}
	public void setLength(int length) {
		this.length = length;
	}
	private Color color;
	private int width;
	private int length;
	private int row;
	private int column;

}
