package edu.udel.jatlas.tictactoe;

public class TicTacToe5x5Piece {
    private char symbol;

    public TicTacToe5x5Piece(char symbol) {
        this.symbol = symbol;
    }
    
    public char getSymbol() {
        return symbol;
    }

    public boolean equals(Object obj) {
        return obj instanceof TicTacToe5x5Piece && ((TicTacToe5x5Piece)obj).symbol == symbol;
    }

    public String toString() {
        return Character.toString(symbol);
    }
}
