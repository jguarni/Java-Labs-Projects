package edu.udel.jatlas.tictactoe.android;

import edu.udel.jatlas.gameframework.Player;
import edu.udel.jatlas.gameframework.Position;
import edu.udel.jatlas.tictactoe.TicTacToe5x5Move;
import edu.udel.jatlas.tictactoe.TicTacToe5x5State;

public class TicTacToe5x5HumanPlayer implements Player<TicTacToe5x5Move, TicTacToe5x5State> {
    protected char symbol;
    private TicTacToe5x5TouchListener touchListener;
    
    public TicTacToe5x5HumanPlayer(char symbol, TicTacToe5x5TouchListener touchListener) {
        this.symbol = symbol;
        this.touchListener = touchListener;
    }

    public TicTacToe5x5Move getNextMove(TicTacToe5x5State state) {
        if (state.getTurn() == symbol) {
            Position pos = touchListener.getTouchEventPosition();
            if (pos != null) {
                return new TicTacToe5x5Move(pos.getRow(), pos.getCol());
            }
        }
        return null;
    }
    
    
    public String getIdentifier() {
        return String.valueOf(symbol);
    }

    public String toString() {
        return getIdentifier();
    }

    
}
