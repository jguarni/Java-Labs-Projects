package edu.udel.jguarni.blockevader;
import java.awt.Color;
//This class will create a block obejct. A block is an object that the evader needs to avoid. A block has a width, height, color, type and
//position defined by its row and column.
public class Block {
	private int width;
	private int height;
	private Color color;
	private String type;
	private int row;
	private int column;
	
	public Block(int width, int height, Color color, String type, int row, int column) {
		this.width = width;
		this.height = height;
		this.color = color;
		this.type = type;
		this.row = row;
		this.column = column;
	}
	//SEtters and Getters
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public char getSymbol(){
		return 'B';
	}
	
	public int getWidth() {
		return width;
	}
	public void setWidth(int width) {
		this.width = width;
	}
	public int getHeight() {
		return height;
	}
	public void setHeight(int height) {
		this.height = height;
	}
	public Color getColor() {
		return color;
	}
	public void setColor(Color color) {
		this.color = color;
	}
	
	public int getRow() {
		return row;
	}
	public void setRow(int row) {
		this.row = row;
	}
	public int getColumn() {
		return column;
	}
	public void setColumn(int column) {
		this.column = column;
	}
	@Override
	public String toString() {
		return "Block [width=" + width + ", height=" + height + ", color="
				+ color + ", type=" + type + "]";
	}

}
