// PS4 Joe Guarni CISC181 October 12th 2013

// A Fruit is an object that has a color and weight.

public abstract class Fruit {

	private String color;
	private double weight;
	
	//Creates an instance of a fruit.
	public Fruit(String color, double weight) {
		this.color = color;
		this.weight = weight;
	}

	public Fruit() {
	}
	//Setters and Getters
	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		this.color = color;
	}

	public double getWeight() {
		return weight;
	}

	public void setWeight(double weight) {
		this.weight = weight;
	}
	// An Equals() method to check if two fruits are equal to each other.
	// In order for a fruit to be equal they must have equal weight and color.
	
	public boolean equals(Object Obj) {
		if (Obj instanceof Fruit) {
			if ((this.getWeight() == ((Fruit) Obj).getWeight()) && (this.getColor() == ((Fruit) Obj).getColor())) {
			return (Fruit) Obj != null; 
			}
		}
		return false;
	}
	//A method to determine the amount of calories in an instance of a fruit.
	public abstract double getCalories();

}
