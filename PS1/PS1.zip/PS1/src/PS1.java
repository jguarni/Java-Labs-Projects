/*
 * PS1 @author Joe Guarni
 * CISC181 - Fall 2013 11 AM
 * September 4th, 2013
 */

public class PS1 {
	/*
	 * Problem 1 This method will measure coldness based off a wind-chill
	 * equation developed by the NWS. It uses air temperature and wind speed to
	 * calculate final wind chill.
	 */
	public static double windChillTemperature(int airtemp, int windspeed) {
		double v = Math.pow(windspeed, 0.16);
		return 35.74 + (0.6215 * airtemp) - (35.75 * v)
				+ (0.4275 * airtemp * v);
	}

	/*
	 * Problem 2 This method will determine the quality of a party based on the
	 * amount of tea and candy brought to it. If it returns 0 the party was bad,
	 * 1 the party was good, or 2 the party was great.
	 */
	public static int teaParty(int tea, int candy) {
		if ((tea >= 5) & (candy >= 5)) {
			if ((tea >= candy * 2) || (candy >= tea * 2)) {
				return 2;
			} else {
				return 1;
			}
		} else {
			return 0;
		}
	}

	/*
	 * Problem 3 This method takes two integers as parameters. It will check
	 * these two integers for a digit that appears in both numbers. If the
	 * number appears in both numbers, the method will return True. If the
	 * number does not appear in both digits the method will return False.
	 */
	public static boolean shareDigit(int num1, int num2) {
		int l1 = num1 / 10;
		int r1 = num1 % 10;
		int l2 = num2 / 10;
		int r2 = num2 % 10;

		boolean a = (l1 == l2) || (l1 == r2) || (r1 == l2) || (r1 == r2);
		return a;

	}

	/*
	 * Problem 4 This method will take an integer as a parameter and find the
	 * closest whole number (smaller) square root. It will then check if the
	 * calculated number divides evenly into the original number. If not, it
	 * will decrease by one in order to find the closest smallest whole number
	 * that divides evenly into the original number.
	 */
	public static int closestFactorToSqrt(int number) {
		int a = (int) Math.sqrt(number);
		while ((number % a) != 0) {
			a = a - 1;
		}
		return a;

	}

	/*
	 * Problem 5 This function will determine odd parity of an integer taken in
	 * as a parameter. This is being determined by adding all of the digits in
	 * the integer together and testing weather it is even or odd. Odd will
	 * return True, Even will return False.
	 */
	public static boolean oddParity(int value) {
		int fvalue = 0;
		while (value != 0) {
			fvalue = fvalue + value % 10;
			value = value / 10;
		}
		boolean a = ((fvalue % 2) != 0);
		return a;

	}

}
