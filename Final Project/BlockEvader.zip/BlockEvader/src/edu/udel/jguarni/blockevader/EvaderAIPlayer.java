
package edu.udel.jguarni.blockevader;

import java.util.ArrayList;
import java.util.List;

import edu.udel.jatlas.gameframework.AIPlayer;
import edu.udel.jatlas.gameframework.Position;

import edu.udel.jguarni.blockevader.JumpMove;
import edu.udel.jguarni.blockevader.Evader;
import edu.udel.jguarni.blockevader.EvaderMove;
import edu.udel.jguarni.blockevader.EvaderState;

public class EvaderAIPlayer extends AIPlayer<EvaderMove, EvaderState> {
	public EvaderAIPlayer() {
		super();
	}

	@Override
	public String getIdentifier() {

		return null;
	}

	@Override
	public List<EvaderMove> getAllValidMoves(EvaderState state) {
		List<EvaderMove> validMoves = new ArrayList<EvaderMove>();

		// well a valid move is anything in Snake
		// (might not be a *good* move though, as you could die on the next
		// tick)
		validMoves.add(new JumpMove(Evader.UP));
		validMoves.add(new JumpMove(Evader.STILL));

		return validMoves;
	}

	@Override
	public double getHeuristicScore(EvaderState state) {
			//EvaderGame g = new EvaderGame(state);
			//g.onTick();


			if (state.isEnd()) {
			return 1;
			}
			// are we about to hit something?
			Position ep = state.getEvader().getPosition();
			for (Block b : state.getBlock()) {
			Position bp = b.getPosition();
			if (ep.getRow() == bp.getRow() && ep.getCol() == bp.getCol() - 1) {
			return 2;
			}
			}
			return 3;
			 
			}

}
