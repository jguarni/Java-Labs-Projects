package edu.udel.jatlas.tictactoe.android;
import javax.microedition.khronos.opengles.GL10;

/**
 * A 3d shape has a position and rotation and size for scaling.
 */
public class Shape3d {
    private Model3d model;
    
    // Size (for scaling)
    private float size;
    
    // Position within scene
    private float x;
    private float y;
    private float z;
    
    private float rotatex;
	private float rotatey;
    private float rotatez;

    public Shape3d(Model3d model) {
        this.setModel(model);
        
        // initialize size to 1 (i.e. no scaling)
        size = 1f;
        
        
        // initialize x, y, and z to 0
        x = 0;
        y = 0;
        z = 0; 
        rotatex = 0;
        rotatey = 0;
        rotatez = 0;
    }

    public float getRotatex() {
		return rotatex;
	}

	public void setRotatex(float rotatex) {
		this.rotatex = rotatex;
	}

	public float getRotatey() {
		return rotatey;
	}

	public void setRotatey(float rotatey) {
		this.rotatey = rotatey;
	}

	public float getRotatez() {
		return rotatez;
	}

	public void setRotatez(float rotatez) {
		this.rotatez = rotatez;
	}

	/**
     * This function draws our square on screen.
     * @param gl
     */
    public void draw(GL10 gl) {
        transform(gl);
        
        model.draw(gl);
    }
    
    /**
     * This method can be overridden to provide additional transformations
     * prior to drawing the triangles for the object
     * 
     * @param gl
     */
    protected void transform(GL10 gl) {
    	
    	
        gl.glScalef(size, size, size);
        gl.glTranslatef(x, y, z);
        
        gl.glRotatef(rotatex, 1.0f, 0.0f, 0.0f);
        gl.glRotatef(rotatey, 0.0f, 1.0f, 0.0f);
        gl.glRotatef(rotatez, 0.0f, 0.0f, 1.0f);
        
       
        
    }


    public float getX() {
        return x;
    }

    public float getY() {
        return y;
    }

    public float getZ() {
        return z;
    }
   
    
    public void setPosition(float x, float y, float z) {
        this.x = x;
        this.y = y;
        this.z = z;
    }
    public void setRotation(float rotatex, float rotatey, float rotatez) {
        this.rotatex = rotatex;
        this.rotatey = rotatey;
        this.rotatez = rotatez;
    }

    public float getSize() {
        return size;
    }

    public void setSize(float size) {
        this.size = size;
    }

	public Model3d getModel() {
		return model;
	}

	public void setModel(Model3d model) {
		this.model = model;
	}
    
    
}
