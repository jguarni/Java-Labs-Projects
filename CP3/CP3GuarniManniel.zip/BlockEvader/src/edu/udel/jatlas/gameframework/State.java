package edu.udel.jatlas.gameframework;

public interface State<S extends State<S>> {
    public S copy();
    public boolean isEnd();
}
