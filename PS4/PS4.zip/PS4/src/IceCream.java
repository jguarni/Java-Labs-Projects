import java.util.List;
//Ice Cream is an edible object.

public class IceCream implements Edible, Colorful{
	public IceCream() {}

	@Override
	//Method that returns the amount of calories in an instance of Ice Cream
	public double getCalories() {
		return 1000.0;
	}

	@Override
	public List<Colorful> getColorfulItems() {
		// TODO Auto-generated method stub
		return null;
	}

}
