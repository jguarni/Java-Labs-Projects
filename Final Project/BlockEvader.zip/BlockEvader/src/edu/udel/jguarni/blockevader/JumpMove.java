package edu.udel.jguarni.blockevader;

import edu.udel.jatlas.gameframework.Position;

public class JumpMove extends EvaderMove {
	
    private int direction;

    public JumpMove(int direction) {
        this.direction = direction;
    }

    public boolean isValid(EvaderState state) {
    	if (state.getEvader().getPosition().getRow() == 3) {
			return true;
		}
    	return false;
    }

    public void make(EvaderState state) {
        state.getEvader().setDirection(direction);
        state.getEvader().setPosition(state.getEvader().getNextPosition());
    }
    
    public int getDirection() {
        return direction;
    }

    public String toString() {
        return "ChangeDirectionMove [direction=" + direction + "]";
    }
}
