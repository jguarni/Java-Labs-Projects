package edu.udel.jguarni.blockevader;



import junit.framework.TestCase;


//This class will create the test cases for BlockEvader. It shows a beginning state, two mid game states, and an end game state. It
//will then print the different states by displaying a grid with the character postions on it. It will also display the current checkpoint
// and the current score.

public class EvaderTests extends TestCase {
/*
	private static Evader beginevader = new Evader(new Position(3, 3), 0);
	private static EvaderState beginstate = new EvaderState(new Block(
			new LinkedList<Position>(Arrays.asList(new Position(3, 2),
					new Position(2, 4), new Position(2, 6), new Position(3, 8),
					new Position(3, 10), new Position(3, 12), new Position(2,
							15), new Position(3, 17))), 0), beginevader, 0, 0,
			5, 20, 0);

	public void test_copy() {
		// for copy to work, the contents of the state need to be the same
		// but the actual references cannot be the same (i.e. we created a new
		// state in memory)

		EvaderState stateCopy = beginstate.copy();
		assertNotSame(beginstate, stateCopy);

		List<Block> blockOriginal = beginstate.getBlock();
		List<Block> blockCopy = stateCopy.getBlock();
		LinkedList<Position> blockorignalblocks;

		for (Block a : blockOriginal) {
			blockorignalblocks.add(a.getBlock());
		}

		LinkedList<Position> copyblocks = blockCopy.getBlocks();

		assertEquals(blockOriginal.getDirection(), blockCopy.getDirection());

		assertEquals(blockorignalblocks, copyblocks);

	}

	public static void main(String[] args) {
		System.out
				.println("\nThese tests show the different states of BlockEvader.\nThe letter E expresses the position of the evader.\nThe number 0 expresses the position of a block.\nThe special"
						+ " character # expresses when the evader loses a life and there is a collision.\n");
		System.out.println(beginstate);

	}
*/
}

