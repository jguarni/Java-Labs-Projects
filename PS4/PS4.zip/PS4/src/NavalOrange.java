//Class for creating naval oranges.
public class NavalOrange extends Orange{

	//Creates an instance of a naval orange with a specified weight. 
	public NavalOrange(double weight) {
		super(weight);
		// TODO Auto-generated constructor stub
	}
	//Method that calculates the amount of calories for an instance of a naval orange.
	public double getCalories() {
		// TODO Auto-generated method stub
		return super.getWeight() * 5 + ((super.getWeight() * 5) * .10);

	}

}
