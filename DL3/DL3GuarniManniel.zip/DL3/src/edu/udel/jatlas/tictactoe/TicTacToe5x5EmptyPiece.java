package edu.udel.jatlas.tictactoe;

/**
 * empty piece represented by a space
 * 
 * @author jatlas
 */
public class TicTacToe5x5EmptyPiece extends TicTacToe5x5Piece {
    public TicTacToe5x5EmptyPiece() {
        super(' ');
    }
}
