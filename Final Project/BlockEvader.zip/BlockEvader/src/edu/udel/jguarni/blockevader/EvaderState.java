package edu.udel.jguarni.blockevader;

import java.util.List;

import edu.udel.jatlas.gameframework.Position;
import edu.udel.jatlas.gameframework.State;
import edu.udel.jguarni.blockevader.EvaderState;

// @Author Joe Guarni & Peter Manniel
// CISC181 Fall 2013 - Checkpoint 1 10/8/2013
// BlockEvader

//This class will create the current state of the game depending on all of the objects passed through it. A snapshot or state of
//the game includes a speed, score, checkpoint, grid postion(represented by a column and row), array of blocks, and an evader.
public class EvaderState implements State<EvaderState> {

	// Creates the accumulated score, speed, and checkpoint
	private long speed;
	private int score;
	private int checkpoint;
	private int row;
	private int column;
	private List<Block> block;
	private Evader evader;
	

	public EvaderState(List<Block> block, Evader evader, long speed, int score, int row, int column,int checkpoint) {
		this.block = block;
		this.evader = evader;
		this.speed = speed;
		this.score = score;
		this.row = row;
		this.column = column;
		this.checkpoint = checkpoint;
	}
	//Setters and Getters
	public List<Block> getBlock() {
		return block;
	}

	public void setBlock(List<Block> block) {
		this.block = block;
	}

	public Evader getEvader() {
		return evader;
	}

	public void setEvader(Evader evader) {
		this.evader = evader;
	}

	public long getSpeed() {
		return speed;
	}

	public void setSpeed(long speed) {
		this.speed = speed;
	}

	public int getScore() {
		return score;
	}

	public void addScore(int score) {
		this.score += score;
	}

	public int getCheckpoint() {
		return checkpoint;
	}

	public void setCheckpoint(int checkpoint) {
		this.checkpoint += checkpoint;
	}

	public int getRow() {
		return row;
	}

	public void setRow(int row) {
		this.row = row;
	}

	public int getColumn() {
		return column;
	}

	public void setColumn(int column) {
		this.column = column;
	}

	@Override
	public String toString() {
		//Creates a game grid of from the row and column properties of the evader state class.
		char[][] gamegrid = new char[row][column];
		for (int i = 0; i < gamegrid.length; i++) {
			for (int j = 0; j < gamegrid[i].length; j++) {
				gamegrid[i][j] = (i == 0 || j == 0 || i == gamegrid.length - 1 || j == gamegrid[i].length - 1) ? 'X'
						: ' ';
			}
		}
		//Places and E where the Evader is currently located in the current state
		int ev1 = evader.getPosition().getRow();
		int ev2 = evader.getPosition().getCol();
		gamegrid[ev1][ev2] = 'E';
		
		// Places a B where the positons of the blocks are located in the current state
		for (Block p : this.block) {
			

			gamegrid[p.getPosition().getRow()][p.getPosition().getCol()] = '0';
			//Places a # symbol where there is a collision between a block and Evader.
			if (gamegrid[ev1][ev2] == gamegrid[p.getPosition().getRow()][p.getPosition().getCol()]) {
				gamegrid[p.getPosition().getRow()][p.getPosition().getCol()] = '#';
			}
		}
		//Turns the infomation from the array into a printed string format. Also
		//displays the current state of the variables checkpoint and score.
		StringBuilder buffer = new StringBuilder();
		buffer.append("Checkpoint " + getCheckpoint()).append("\n");
		buffer.append("Score " + getScore()).append("\n");
		for (char[] row : gamegrid) {
			buffer.append(row);
			buffer.append('\n');
		}
		return buffer.toString();
	}
	public boolean isEnd() {
		
		Position Evaderpos = evader.getPosition();
		
		if (isWall(Evaderpos.getRow(),Evaderpos.getCol())) {
			return true;
		}
		for (Block p : this.block){
			if ((p.getBlock().getRow() == this.evader.getPosition().getRow()) && (p.getBlock().getCol()) == this.evader.getPosition().getCol()){
				return true;
			}
		
		}
		
		return false;
	}
    public boolean isValid(Position p) {
    	return row < 0 || p.getCol() < 0 || row >= getRow() || p.getCol() >= getColumn();
    }
    public boolean isWall(int row, int col) {
        return row < 1 || col < 1 || row >= getRow() || col >= getColumn();
    }

	
	@Override
	public EvaderState copy() {
		return new EvaderState(block, evader.copy(), speed, score, row, column, checkpoint);
	}
	public int getLevel() {
		// TODO Auto-generated method stub
		return 0;
	}
	
	}

