package edu.udel.jguarni.app.blockevader;

import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import edu.udel.jatlas.gameframework.Position;
import edu.udel.jguarni.blockevader.EvaderGame;

public class EvaderMoveListener implements View.OnTouchListener, View.OnKeyListener {
    private EvaderActivity activity;

    // the last position selected in game coordinates (could be either touched or keyed pressed)
    private Position moveToPosition;
    
    public EvaderMoveListener(EvaderActivity activity) {
        this.activity = activity;
    }

    public boolean onTouch(View v, MotionEvent event) {
        int action = event.getAction();
        EvaderGame game = activity.getCurrentGame();
        if (game != null) {
            // is the game ended? if so restart it!
            if (game.isEnd()) {
                activity.restartGame();
            }
            else {
                // where did they click on the board?
                int row = (int)((event.getY() / v.getHeight()) * 
                        game.getCurrentState().getRow());
                int col = (int)((event.getX() / v.getWidth()) * 
                        game.getCurrentState().getColumn());
                
                if (action == MotionEvent.ACTION_DOWN) {
                    makePlayerMove(new Position(row, col));
                }
            }
        }
        
        // we don't need any more events in this sequence
        return false;
    }
    
    public boolean onKey(View v, int keyCode, KeyEvent event) {
        Position current = activity.getCurrentGame().getCurrentState().getEvader().getPosition();
        int row = current.getRow();
        int col = current.getCol();
        
        if (event.getKeyCode() == KeyEvent.KEYCODE_DPAD_UP) {
            row--;
        }
        else if (event.getKeyCode() == KeyEvent.KEYCODE_DPAD_DOWN) {
            row++;
        }
        else if (event.getKeyCode() == KeyEvent.KEYCODE_DPAD_LEFT) {
            col--;
        }
        else if (event.getKeyCode() == KeyEvent.KEYCODE_DPAD_RIGHT) {
            col++;
        }
        makePlayerMove(new Position(row, col));
        
        return false;
    }
    
    public Position getMoveToPosition() {
        return moveToPosition;
    }
   
    private void makePlayerMove(Position moveTo) {
        // forces a call to updatePlayerMoves when there is a moveToPosition
        // that the SnakeHumanPlayer can use
        moveToPosition = moveTo;
        activity.getCurrentGame().updatePlayerMoves();
        moveToPosition = null;
    }
}
