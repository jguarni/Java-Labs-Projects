package ps5;

import java.io.File;
import java.io.IOException;

import java.util.Comparator;
import java.util.HashMap;
import java.util.Map;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map.Entry;
import java.util.Scanner;

public class Parser implements Comparator<String> {

	// used by the methods of Parser
	private Map<String, Integer> frequencies;

	public Parser() {
		// do not change the constructor, this initializes an empty Map
		frequencies = new HashMap<String, Integer>();
	}

	public void parse(String filename) throws IOException {
		//This method parses a textfile. It scans through the file
		//and creates a map with the word as the key and the number of
		//occurances as the value.

		@SuppressWarnings("resource")
		Scanner book = new Scanner(new File(filename));

		while (book.hasNext()) {
			String word = book.next().toLowerCase();
			if (word != null) {
				word = word.replace("'", "");
				word = word.replace("-", "");
				word = word.replace(":", "");
				word = word.replace(",", "");
				word = word.replace("?", "");
				word = word.replace("!", "");
				word = word.replace(";", "");
				word = word.replace(".", "");
				word = word.replace("]", "");
				word = word.replace("[", "");
				word = word.replace(")", "");
				word = word.replace("(", "");
				if (this.frequencies.containsKey(word)) {
					this.frequencies
							.put(word, (this.frequencies.get(word)) + 1);
				} else {
					this.frequencies.put(word, 1);
				}

			}

		}
		return;
	}

	public int getCount(String word) {
		//Gets the occurance count of a specific word from a Parser.
		int num = 0;
		for (Entry<String, Integer> entry : this.frequencies.entrySet()) {
			if (entry.getKey().equals(word)) {
				num = entry.getValue();
			}
		}
		return num;
	}

	public List<String> getWordsInOrderOfFrequency() {
		//Takes a frequecy and sorts it based off the number of occurances it
		//has in the book.

		List<String> valueset = new ArrayList<String>(this.frequencies.keySet());
		Collections.sort(valueset, this);
		return valueset;

	}

	public List<String> commonWords(Parser obj1) {
		//Finds the common words between two parser frequencies.
		//Returns a list with the common words between the two frequencies.
		List<String> objlist = new ArrayList<String>();
		List<String> simlist = new ArrayList<String>();
		objlist = obj1.getWordsInOrderOfFrequency();
		for (String ele : objlist) {
			if (this.frequencies.containsKey(ele)) {
				simlist.add(ele);
			}

		}
		simlist.remove("");
		return simlist;

	}

	public int totalCommonTop100Words(Parser obj1) {
		//Takes the top 100 words from two frequency lists and comapres
		//the similarities between the two and returns the integer value.

		List<String> list1 = new ArrayList<String>(
				this.getWordsInOrderOfFrequency());
		List<String> list2 = new ArrayList<String>(
				obj1.getWordsInOrderOfFrequency());
		List<String> list3 = new ArrayList<String>();

		List<String> subItems1 = list1
				.subList(list1.size() - 100, list1.size());
		List<String> subItems2 = list2
				.subList(list2.size() - 100, list2.size());

		for (String ele : subItems2) {

			if (subItems1.contains(ele)) {
				list3.add(ele);
			}
		}

		return list3.size();

	}

	public int compare(String o1, String o2) {
		//Compares two parser frequencies and returns the comparison between the two.
		int value1 = (getCount(o1));
		int value2 = (getCount(o2));

		return Double.compare(value1, value2);
	}

	public static void main(String[] args) throws IOException {
		//Creates each element
		Parser hamlet = new Parser();
		Parser juliuscaesar = new Parser();
		Parser othello = new Parser();
		Parser romeoandjuliet = new Parser();
		Parser twelfthnight = new Parser();
		Parser[] plays = new Parser[5];
		
		//Parses each element
		hamlet.parse("./hamlet.txt");
		juliuscaesar.parse("./juliuscaesar.txt");
		othello.parse("./othello.txt");
		romeoandjuliet.parse("./romeoandjuliet.txt");
		twelfthnight.parse("./twelfthnight.txt");

		plays[0] = hamlet;
		plays[1] = juliuscaesar;
		plays[2] = othello;
		plays[3] = twelfthnight;
		plays[4] = twelfthnight;
		int x = 0;
		for (Parser ele : plays) {
			for (Parser ele2 : plays) {
				if ((ele.totalCommonTop100Words(ele2) > x)
						&& (!ele2.equals(ele))) {
					x = ele.totalCommonTop100Words(ele2);
					Parser a = ele; //The first parser in common
					Parser b = ele2; //The second parser in common
					//ps5.Parser@6bf7dab1 and ps5.Parser@3f9432e0 are the two with
					//the most common. Joe Guarni
				}
			}

		}

	}

}
