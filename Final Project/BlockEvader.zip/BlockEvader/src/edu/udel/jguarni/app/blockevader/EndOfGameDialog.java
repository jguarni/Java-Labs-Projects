package edu.udel.jguarni.app.blockevader;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.widget.EditText;
import edu.udel.jatlas.gameframework.GameStateListener;
import edu.udel.jguarni.blockevader.EvaderAIPlayer;
import edu.udel.jguarni.blockevader.EvaderGameRecord;
import edu.udel.jguarni.blockevader.EvaderState;

public class EndOfGameDialog implements GameStateListener, DialogInterface.OnClickListener {
    private EvaderActivity activity;
    private EditText input;
    private EvaderGameRecord lastRecord;

    public EndOfGameDialog(EvaderActivity activity) {
        this.activity = activity;
    }
    
    public void onClick(DialogInterface dialog, int whichButton) {
        // format value to only valid letters, and only the first 3, uppercase
        String value = String.format("%3s", 
            this.input.getText().toString().replaceAll("[^a-zA-Z]", "")).substring(0,3).toUpperCase();

        // get the score integer to store in database
        Integer score = activity.getCurrentGame().getCurrentState().getScore();

        // create the record
        lastRecord = new EvaderGameRecord(value, score, System.currentTimeMillis());
        
        // insert record to database
        activity.getDatabase().insertGameRecord(lastRecord);
        
        activity.setHighScoreRecord(lastRecord);
        // force the scoreboard/view to update
        activity.getScoreboard().onStateChange(activity.getCurrentGame());
    }
    
    /**
     * Gets the last initials entered.  Will return "" if none entered yet.
     * 
     * @return
     */
    public String getLastInitials() {
        String lastInitials = "";
        if (this.lastRecord != null) {
            lastInitials = lastRecord.getPlayer();
        }
        return lastInitials;
    }

    
    public void onStateChange(Object game) {
        if (game == activity.getCurrentGame()) {
            EvaderState state = activity.getCurrentGame().getCurrentState();
            // don't let the AI get the high score at snake
            if (state.isEnd() && !activity.isFinishing() 
                    && !(activity.getCurrentGame().getPlayers().get(0) instanceof EvaderAIPlayer)) {
                
                int score = activity.getCurrentGame().getCurrentState().getScore();
                EvaderGameRecord highScoreRecord = activity.getHighScoreRecord();
                if (highScoreRecord == null || score > highScoreRecord.getScore()) {
                    // pop up a dialog box telling them to enter name
                    AlertDialog.Builder alert = new AlertDialog.Builder(activity);
    
                    alert.setTitle("New High Score of " + score + "!");
                    alert.setMessage("Please enter your initials:");
                    
                    // get these so we can prompt them with the last initials to start
                    // (makes it easy to play multiple games rather than having them retype
                    //  their initials every time)
                    String lastInitials = getLastInitials();
                    this.input = new EditText(activity);
                    this.input.setText(lastInitials);
                        
                    // Set the view to the EditText 
                    alert.setView(this.input);
                    
                    alert.setPositiveButton("Ok", this);
                    alert.show();
                }
            }
        }
    }
    
}

