package DL1;

import java.util.Collections;

public class DotMatrix {
	private char[] sequence1;
	private char[] sequence2;
	private boolean[][] matrix;

	/**
	 * Computes a Boolean matrix where a match between seq1 and seq2 at a
	 * position would be true, otherwise false.
	 * 
	 * @param seq1
	 * @param seq2
	 */
	public DotMatrix(char[] sequence1, char[] sequence2) {
		// This creates a DotMatix object
		this.sequence1 = sequence1;
		this.sequence2 = sequence2;
		this.matrix = new boolean[sequence1.length][sequence2.length];

		for (int i = 0; i < sequence1.length; i++) {
			for (int j = 0; j < sequence2.length; j++) {
				if (sequence1[i] == sequence2[j]) {
					matrix[i][j] = true;
				}
			}

		}

	}

	public char[] getSequence1() {
		return sequence1;
	}

	public char[] getSequence2() {
		return sequence2;
	}

	public boolean[][] getMatrix() {
		return matrix;
	}

	/**
	 * Computes the maximum sequential number of matches in a diagonal path
	 * starting at the given row and column and going "downwards to the right"
	 * in the matrix.
	 * 
	 * @param row
	 * @param column
	 * @return the max score
	 */
	public int diagonalMatchScore(int row, int column) {
		// This method finds the max diagonal score in a matrix given the column and row.
		int count = 0;
		int[] match;
		int num = 0;
		match = new int[matrix.length];
		int largest = match[0];

		if (column > row) {
			num = column;
		} else {
			num = row;
		}

		for (int i = 0; i < matrix.length - num; i++) {
			if ((matrix[row + i][column + i]) == true) {
				count++;
				match[i] = count;
			} else {
				count = 0;
			}
		}
		for (int j = 0; j < match.length; j++) {
			if (match[j] > largest) {
				largest = match[j];

			}
		}

		if (count == 1) {
			return count;
		} else {
			return largest;
		}
	}

	/**
	 * Computes the maximum diagonalMatchScore of any diagonal in the matrix
	 * (diagonals "start" at the left of each row and at the top of each
	 * column).
	 * 
	 * @return the max overall score
	 */
	public int maxDiagonalAlignment() {
		// This method finds the max diagonal score in a matrix by comparing all of the maxdiagonal scores.
		int[] largestfind;
		largestfind = new int[matrix.length];
		int largest = largestfind[0];
		
		for (int i = 0; i< matrix.length; i++) {
			 largestfind[i]= diagonalMatchScore(0,i);
		}
		
		for (int j = 0; j < largestfind.length; j++) {
			if (largestfind[j] > largest) {
				largest = largestfind[j];
			}
		
	}
		return largest;
	}

	/**
	 * Returns a String dot matrix representation of two sequences being
	 * aligned. Places the seq1 value down the leftmost column, and seq2 above
	 * the topmost row. Places an x at every place that is true in the
	 * dotMatrix.
	 * 
	 * @param seq1
	 * @param seq2
	 * @param dotMatrix
	 */
	public String toString() {
		StringBuilder b = new StringBuilder();
		b.append("  ");
		for (int i = 0; i < sequence2.length; i++) {
			b.append(sequence2[i]);
			b.append(" ");
		}
		b.append("\n");

		b.append(" +");
		for (int i = 0; i < sequence2.length; i++) {
			b.append("--");
		}
		b.append("\n");

		for (int i = 0; i < sequence1.length; i++) {
			b.append(sequence1[i]);
			b.append("|");
			for (int j = 0; j < sequence2.length; j++) {
				b.append(matrix[i][j] ? "x" : " ");
				b.append(" ");
			}
			b.append("\n");
		}
		return b.toString();
	}
}
