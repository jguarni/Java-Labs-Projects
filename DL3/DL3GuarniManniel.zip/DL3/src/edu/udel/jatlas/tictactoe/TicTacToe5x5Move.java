package edu.udel.jatlas.tictactoe;

import edu.udel.jatlas.gameframework.Move;



public class TicTacToe5x5Move implements Move<TicTacToe5x5State> {
    private int row;
    private int column;
    
    public TicTacToe5x5Move(int row, int column) {
        this.row = row;
        this.column = column;
    }
    
    public int getRow() {
        return row;
    }

    public int getColumn() {
        return column;
    }
    
    public boolean isValid(TicTacToe5x5State s) {
        return row >= 0 && column >= 0 && 
                row < s.getBoard().length && column < s.getBoard()[row].length &&
                s.getBoard()[row][column] instanceof TicTacToe5x5EmptyPiece;
    }
    
    public void make(TicTacToe5x5State s) {
        s.getBoard()[row][column] = new TicTacToe5x5Piece(s.getTurn());
        s.changeTurn();
    }
    
    public String toString() {
        return "Move:"+row+","+column;
    }
}
