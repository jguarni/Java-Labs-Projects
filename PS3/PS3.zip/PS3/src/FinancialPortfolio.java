//Written by Joe Guarni [CISC 181 Fall Section 010]
//This class will represent a financial portfolio. A Financial portfolio has a name and an array of accounts.
public class FinancialPortfolio {
	private String name;
	private Account[] Accounts;

	public FinancialPortfolio(String name, Account[] Accounts) {
		this.name = name;
		this.Accounts = Accounts;
	}

	public Account[] getAccounts() {
		return Accounts;
	}

	public String getName() {
		return name;
	}

	public double getNetBalance() {
		//This method will get the net balance of all the accounts in the portfolio.
		double total = 0;
		for (Account a : Accounts) {
			total += a.getBalance();
		}
		return total;

	}

	public void endOfMonth() {
		// This method will add each of the accounts specified monthly interest to the balance of the account.
		for (Account a : Accounts) {
			a.addMonthlyInterest();
		}
	}

	public Account getHighestRateIndebtedAccount() {
		//This method will iterate over the accounts in the portfolio and find the account with the most negative balance and highest interest rate.
		Account CompAccount = null;
		for (Account a : Accounts) {
			if (a.getBalance() < 0) {
				if (CompAccount == null
						|| a.getMonthinterest() >= CompAccount
								.getMonthinterest()) {
					CompAccount = a;

				}
			}
		}
		return CompAccount;
	}

	public Account getLowestInterestAccountWithPositiveBalance() {
		//This method will iterate over the accounts in the portfolio and find the account with the most positive balance and lowest interest rate.
		Account CompAccount = null;
		for (Account a : Accounts) {
			if (a.getBalance() > 0) {
				if (CompAccount == null
						|| a.getMonthinterest() <= CompAccount
								.getMonthinterest()) {
					CompAccount = a;

				}
			}
		}
		return CompAccount;
	}

	public void payoffDebt() {
		/*
		 * This method will iterate over the accounts in a portfolio and pay the most negative balance and highest interest rate account with the most positive balance  
		 * and lowest interest rate account. It will find these accounts through the getLowest.. and getHighest.. methods written in this class. It will then use the payoffBalance method 
		 * to make the transfers between the specified accounts. This method will keep running until all negative balances are gone or there are no more positive funds to exhaust.
		*/
	
		for (int i = 0; i < this.Accounts.length; i++) {
			if ((this.getLowestInterestAccountWithPositiveBalance() != null)
					&& (this.getHighestRateIndebtedAccount()) != null) {
				this.getLowestInterestAccountWithPositiveBalance()
						.payoffBalance(this.getHighestRateIndebtedAccount());
			}
		}

	}
}