package edu.udel.jatlas.tictactoe.android;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;

import javax.microedition.khronos.opengles.GL10;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.opengl.GLUtils;
import android.util.Log;

/**
 * Allows a bitmap to be loaded from the assets folder and used
 * as a texture for a square model.
 * 
 * Loading textures for other shapes is possible but requires
 * mapping of the texture coordinates to vertices which is not
 * straight-forward.
 * 
 * @author jatlas
 */
public class TexturedSquare extends Square {
    private int textureId;
    private FloatBuffer texBuffer;
    private boolean loaded;
    private Context context;
    private String imageAssetPath;
    private Shape3dRenderer renderer;
    
    public TexturedSquare(float sideLength, float[] color, Context context, String imageAssetPath, Shape3dRenderer renderer) {
        super(sideLength, color);

        this.context = context;
        this.imageAssetPath = imageAssetPath;
        this.renderer = renderer;
        this.loaded = false;
        
        float[] texCoords = { // Texture coords for the above face -- matches order in Square
                              0.0f, 0.0f,  // C. left-top 
                              0.0f, 1.0f,  // A. left-bottom
                              1.0f, 1.0f,  // B. right-bottom                        
                              1.0f, 0.0f   // D. right-top
                           };
        
        // Setup texture-coords-array buffer, in float. An float has 4 bytes
        ByteBuffer tbb = ByteBuffer.allocateDirect(texCoords.length * 4);
        tbb.order(ByteOrder.nativeOrder());
        texBuffer = tbb.asFloatBuffer();
        texBuffer.put(texCoords);
        texBuffer.position(0);
    }

    @Override
    public void draw(GL10 gl) {
        if (!loaded) {
            try {
                loadTexture(gl, context);
                loaded = true;
            }
            catch (IOException e) {
                Log.e("TexturedSquare.draw", e.getMessage());
            }
        }
    
        if (loaded) {
            gl.glEnable(GL10.GL_TEXTURE_2D);  // Enable texture
            gl.glEnableClientState(GL10.GL_TEXTURE_COORD_ARRAY);  // Enable texture-coords-array
            gl.glBindTexture(GL10.GL_TEXTURE_2D, textureId); // Bind to texture
            gl.glTexCoordPointer(2, GL10.GL_FLOAT, 0, texBuffer); // Define texture-coords buffer
            
            super.draw(gl);
            
            gl.glDisableClientState(GL10.GL_TEXTURE_COORD_ARRAY);
            gl.glDisable(GL10.GL_TEXTURE_2D);  
        }
        else {
            // draw without the texture
            super.draw(gl);
        }
    }
    
    // Load an image into GL texture
    private void loadTexture(GL10 gl, Context context) throws IOException {
        Integer id = renderer.getGLTextureId(imageAssetPath);
        if (id == null) {
            int[] textureIDs = {0};
            gl.glGenTextures(1, textureIDs, 0); // Generate texture-ID array
            textureId = textureIDs[0];
            
            gl.glBindTexture(GL10.GL_TEXTURE_2D, textureId); // Bind to texture
                                                                 // ID
            // Set up texture filters
            gl.glTexParameterf(GL10.GL_TEXTURE_2D, GL10.GL_TEXTURE_MIN_FILTER, GL10.GL_NEAREST);
            gl.glTexParameterf(GL10.GL_TEXTURE_2D, GL10.GL_TEXTURE_MAG_FILTER, GL10.GL_LINEAR);
    
            // Construct a BitMap from an asset
            Bitmap bitmap = BitmapFactory.decodeStream(
                context.getAssets().open(imageAssetPath));
    
            // Build Texture from loaded bitmap for the currently-bind texture ID
            GLUtils.texImage2D(GL10.GL_TEXTURE_2D, 0, bitmap, 0);
            bitmap.recycle();
            
            renderer.setGLTextureId(imageAssetPath, textureId);
        }
        else {
            textureId = id;
        }
    }

    
}
