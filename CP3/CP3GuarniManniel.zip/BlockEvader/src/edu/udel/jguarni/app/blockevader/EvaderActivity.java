package edu.udel.jguarni.app.blockevader;

import android.os.Bundle;
import android.app.Activity;
import android.view.Menu;

import android.app.Activity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.LinearLayout;
import edu.udel.jatlas.gameframework.Player;
import edu.udel.jatlas.gameframework.android.AndroidTickManager;
import edu.udel.jguarni.blockevader.EvaderAIPlayer;
import edu.udel.jguarni.blockevader.EvaderGame;
import edu.udel.jguarni.blockevader.EvaderMove;
import edu.udel.jguarni.blockevader.EvaderState;


public class EvaderActivity extends Activity {
    
    private EvaderView gameView;
    private Scoreboard scoreboard;
    
    private EvaderGame game;
    private EvaderMoveListener moveListener;

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
        initGUI();
        
        //soundManager = new SnakeSoundManager(this);
        //soundManager.init();
        
        game = newOnePlayerGame();
        startGame(game);
    }

    private void initGUI() {
        gameView = new EvaderView(this);
        scoreboard = new Scoreboard(this);
        
        moveListener = new EvaderMoveListener(this);
        gameView.setOnTouchListener(moveListener);
        gameView.setOnKeyListener(moveListener);
        
        LinearLayout withScoreboard = new LinearLayout(this);
        withScoreboard.setOrientation(LinearLayout.VERTICAL);
        withScoreboard.addView(scoreboard);
        withScoreboard.addView(gameView);
        
        setContentView(withScoreboard);        
    }

    public boolean onCreateOptionsMenu(Menu menu){
        menu.add("Next Level"); // cheat!
        menu.add("Demo");
        menu.add("1 Player Game");
        menu.add("Restart");
        menu.add("Quit");
        return true;
    }
    
    public boolean onOptionsItemSelected(MenuItem item) {
        CharSequence title = item.getTitle();
        if (title.equals("Next Level")) {
            if (game != null) {
                game.nextLevel();
            }
        }
        if (title.equals("Demo")) {
            game = newAIGame();
            startGame(game);
        }
        else if (title.equals("1 Player Game")) {
            game = newOnePlayerGame();
            startGame(game);
        }
        else if (title.equals("Restart")) {
            // start a new game with the same players as previous game
            restartGame();
        }
        else if (title.equals("Quit")) {
            finish();
        }
        return true;
    }
    

	public EvaderGame getCurrentGame() {
        return game;
    }

    @Override
    protected void onPause() {
        game.stop(); // forces game not to run in background
        super.onPause();
    }


    private void startGame(EvaderGame game) {
        game.addStateChangeListener(gameView);
        game.addStateChangeListener(scoreboard);
        
        
        game.start();
        AndroidTickManager.manageGame(game);
    }
    
    public void restartGame() {
        EvaderGame newGame = new EvaderGame();
        for (Player<EvaderMove, EvaderState> p : game.getPlayers()) {
            newGame.addPlayer(p);
        }
        game = newGame;
        startGame(game);
    }
    
    private EvaderGame newOnePlayerGame() {
        EvaderGame game = new EvaderGame();
        EvaderHumanPlayer human = new EvaderHumanPlayer(moveListener);
        game.addPlayer(human);
        return game;
    } 
    
    
    private EvaderGame newAIGame() {
    	EvaderGame game = new EvaderGame();
    	EvaderAIPlayer ai = new EvaderAIPlayer();
        game.addPlayer(ai);
        return game;
    }
}
