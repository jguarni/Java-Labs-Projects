package edu.udel.jguarni.blockevader;

import edu.udel.jatlas.gameframework.Position;
import edu.udel.jguarni.blockevader.EvaderState;

// This class will create an Evader object. The evader is the object that is avoiding the blocks that are onward towards it. The evader
// has a color, width, length, and a postion that is defined by its row and column.

public class Evader extends Piece<Evader> {
	public static final int DIRECTION_STILL = 0;
	public static final int DIRECTION_UP = 1;
	public static final int DIRECTION_DOWN = 2;

	private int direction;
	private Position position;

	public Evader(Position position, int direction) {
		super(position);
		this.direction = direction;
		this.position = position;
	}

	// Setters and Getters

	public int getDirection() {
		return direction;
	}

	public void setDirection(int direction) {
		this.direction = direction;
	}

	public Evader copy() {
		return new Evader(position, direction);
	}

	public Position getPosition() {
		return position;
	}

	public void setPosition(Position position) {
		this.position = position;
	}


	public void onTick(EvaderState state) {
		
		
	}
}
