package edu.udel.jguarni.app.blockevader;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.graphics.RectF;
import android.util.Log;
import android.view.View;
import edu.udel.jatlas.gameframework.GameStateListener;
import edu.udel.jatlas.gameframework.Position;
import edu.udel.jguarni.blockevader.Evader;
import edu.udel.jguarni.blockevader.Block;
// Joe Guarni & Peter Manniel Project Checkpoint 3
public class EvaderView extends View implements GameStateListener {

	protected EvaderActivity activity;
	private int width;
	private int height;
	private float scale_x;
	private float scale_y;
	private int rows;
	private int cols;
	private Map<String, Bitmap> imageMap;

	public EvaderView(EvaderActivity context) {
		super(context);
		activity = context;

		setFocusable(true);
		setFocusableInTouchMode(true);
	}

	protected void onDraw(Canvas canvas) {
		super.onDraw(canvas);

		drawWalls(canvas);
		drawEvader(canvas);
		drawBlock(canvas);

	}

	public void drawEvader(Canvas canvas) {
		Bitmap evaderImage = getImageMap().get("meatlover");
		Evader evader = activity.getCurrentGame().getCurrentState().getEvader();
		setRectFromPosition(evader.getPosition());
		canvas.drawBitmap(evaderImage, null, rectF, null);
	}
	public void drawBlock(Canvas canvas) {
        Bitmap blockImage = getImageMap().get("spikebox");
        List<Block> block = activity.getCurrentGame().getCurrentState().getBlock();
        for (Block p : block) {
        	setRectFromPosition(p.getPosition());
        	canvas.drawBitmap(blockImage, null, rectF, null);
        }
    }

	private Map<String, Bitmap> getImageMap() {
		if (imageMap == null) {
			imageMap = new HashMap<String, Bitmap>();
			try {
				String[] files = getContext().getAssets().list("images");

				for (String imageName : files) {
					// Construct a BitMap from an asset
					Bitmap bitmap = BitmapFactory.decodeStream(getContext()
							.getAssets().open("images/" + imageName));
					imageMap.put(imageName.replaceFirst("\\..*", ""), bitmap);
				}
			} catch (IOException e) {
				Log.e("Snake", "IOException", e);
			}
		}
		return imageMap;
	}

	RectF rectF = new RectF();

	private void setRectFromPosition(Position position) {
		float left = scale_x * position.getCol();
		float top = scale_y * position.getRow();
		float right = left + scale_x;
		float bottom = top + scale_y;
		rectF.set(left, top, right, bottom);
	}

	public void drawWalls(Canvas canvas) {
		Bitmap wall = getImageMap().get("blockimage");

		// draw walls along the edges
		float left = 0;
		float right = (cols - 1) * scale_x;
		for (int row = 0; row < rows; row++) {
			float topOfRow = scale_y * row;
			float bottomOfRow = topOfRow + scale_y;

			rectF.set(left, topOfRow, 0 + scale_x, bottomOfRow);
			canvas.drawBitmap(wall, null, rectF, null);
			rectF.set(right, topOfRow, right + scale_x, bottomOfRow);
			canvas.drawBitmap(wall, null, rectF, null);
		}
		float top = 0;
		float bottom = (rows - 1) * scale_y;
		for (int col = 1; col < cols - 1; col++) {
			float leftOfColumn = scale_x * col;
			float rightOfColumn = leftOfColumn + scale_x;

			rectF.set(leftOfColumn, top, rightOfColumn, scale_y);
			canvas.drawBitmap(wall, null, rectF, null);
			rectF.set(leftOfColumn, bottom, rightOfColumn, bottom + scale_y);
			canvas.drawBitmap(wall, null, rectF, null);
		}
	}

	protected void onSizeChanged(int w, int h, int oldw, int oldh) {
		super.onSizeChanged(w, h, oldw, oldh);

		width = w;
		height = h;

		updateScaling();
	}

	private void updateScaling() {
		if (activity.getCurrentGame() != null) {
			rows = activity.getCurrentGame().getCurrentState().getRow();
			cols = activity.getCurrentGame().getCurrentState().getColumn();

			scale_x = (float) width / (float) cols;
			scale_y = (float) height / (float) rows;
		}
	}

	public void onStateChange(Object game) {
		if (game == this.activity.getCurrentGame()) {
			invalidate();
		}
	}
}
