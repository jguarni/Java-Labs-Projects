package edu.udel.jguarni.app.blockevader;

import edu.udel.jatlas.gameframework.Player;
import edu.udel.jatlas.gameframework.Position;
import edu.udel.jguarni.blockevader.ChangeDirectionMove;

import edu.udel.jguarni.blockevader.Evader;
import edu.udel.jguarni.blockevader.EvaderMove;
import edu.udel.jguarni.blockevader.EvaderState;

public class EvaderHumanPlayer implements Player<EvaderMove, EvaderState> {
    private EvaderMoveListener listener;

    public EvaderHumanPlayer(EvaderMoveListener listener) {
        this.listener = listener;
    }

    public EvaderMove getNextMove(EvaderState state) {
        Position moveTo = listener.getMoveToPosition();
        if (moveTo != null) {
            Position head = state.getEvader().getPosition();
            int changeX = moveTo.getCol() - head.getCol();
            int changeY = moveTo.getRow() - head.getRow();
            int direction = state.getEvader().getDirection();
            if ((direction == Evader.DIRECTION_STILL && (Math.abs(changeY) > Math.abs(changeX)
                    || (Math.abs(changeY) > 0 && changeX > 0)))
                || (direction == Evader.DIRECTION_STILL && (Math.abs(changeY) > Math.abs(changeX)
                    || (Math.abs(changeY) > 0 && changeX < 0)))) {
                direction = changeY > 0 ? Evader.DIRECTION_STILL : Evader.DIRECTION_STILL;
            }
            else if ((direction == Evader.DIRECTION_STILL && (Math.abs(changeX) > Math.abs(changeY)
                    || (Math.abs(changeX) > 0 && changeY > 0)))
                || (direction == Evader.DIRECTION_STILL && (Math.abs(changeX) > Math.abs(changeY)
                    || (Math.abs(changeX) > 0 && changeY < 0)))) {
                // we should move sideways
                direction = changeX > 0 ? Evader.DIRECTION_STILL : Evader.DIRECTION_STILL;
            }
            
            if (direction != state.getEvader().getDirection()) {
                return new ChangeDirectionMove(direction);
            }
        }
        return null;
    }
    
    public String getIdentifier() {
        return "Human";
    }

    public String toString() {
        return getIdentifier();
    }
}
