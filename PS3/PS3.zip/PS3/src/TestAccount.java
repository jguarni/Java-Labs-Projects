import junit.framework.TestCase;

public class TestAccount extends TestCase {

	public void test_series() {
		Account testAccount = new Account("John Doe", 0, 0.005);
		testAccount.deposit(50);
		testAccount.withdraw(10);
		testAccount.addMonthlyInterest();

		assertEquals(40.2, testAccount.getBalance(), 0.01);
	}

	public void testDeposit() {
		Account testAccount1 = new Account("Joe G", 50, 0.005);
		Account testAccount2 = new Account("Rick D", 60, 0.006);
		Account testAccount3 = new Account("Pete N", 70, 0.007);

		testAccount1.deposit(10);
		testAccount2.deposit(20);
		testAccount3.deposit(30);

		assertEquals(60.0, testAccount1.getBalance());
		assertEquals(80.0, testAccount2.getBalance());
		assertEquals(100.0, testAccount3.getBalance());

	}

	public void testWithdraw() {
		Account testAccount1 = new Account("Joe G", 50, 0.005);
		Account testAccount2 = new Account("Rick D", 60, 0.006);
		Account testAccount3 = new Account("Pete N", 70, 0.007);
		Account testAccount4 = new Account("Joey", 70, 0.007, -50); // Credit
																	// Style
																	// Account
		Account testAccount5 = new Account("Dave", 100, 0.007, -100); // Credit
																		// Style
																		// Account
		Account testAccount6 = new Account("John", 85, 0.007, -300); // Credit
																		// Style
																		// Account

		testAccount1.withdraw(15);
		testAccount2.withdraw(20);
		testAccount3.withdraw(50);
		testAccount4.withdraw(100);
		testAccount5.withdraw(150);
		testAccount6.withdraw(115);

		assertEquals(35.0, testAccount1.getBalance());
		assertEquals(40.0, testAccount2.getBalance());
		assertEquals(20.0, testAccount3.getBalance());
		assertEquals(-30.0, testAccount4.getBalance());
		assertEquals(-50.0, testAccount5.getBalance());
		assertEquals(-30.0, testAccount6.getBalance());
	}

	public void testMonthlyInterest() {
		Account testAccount1 = new Account("Joe G", 85, 0.005);
		Account testAccount2 = new Account("Rick D", 90, 0.006);
		Account testAccount3 = new Account("Pete N", 150, 0.007);

		testAccount1.addMonthlyInterest();
		testAccount2.addMonthlyInterest();
		testAccount3.addMonthlyInterest();

		assertEquals(85.425, testAccount1.getBalance());
		assertEquals(90.54, testAccount2.getBalance());
		assertEquals(151.05, testAccount3.getBalance());
	}

	public void test_payoffDebt() {
		
		Account positive = new Account("John Doe", 500.0, 0);
		Account negative = new Account("John Doe", -250.0, 0.01, -5000);

		// won't do anything since we can't use a negative balance account to payoff a positive balance account
		
		negative.payoffBalance(positive);
		assertEquals(-250.0, negative.getBalance());
		assertEquals(500.0, positive.getBalance());
	
		 // this will pay off the entire negative balance
		 positive.payoffBalance(negative); assertEquals(0.0,
		 negative.getBalance()); assertEquals(250.0, positive.getBalance());
		 
		 Account otherNegative = new Account("John Doe", -1000.0, 0.01,
		 -5000);
		 
		 // this will pay off as much as it can, but will still leave some
		 // negative balance because there is not enough money // in the positive Account 
		 positive.payoffBalance(otherNegative);
		 
		 assertEquals(-750.0, otherNegative.getBalance()); assertEquals(0.0,
		 positive.getBalance()); }
		 
}
