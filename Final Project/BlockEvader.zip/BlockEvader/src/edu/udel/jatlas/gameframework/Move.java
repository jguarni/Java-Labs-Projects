package edu.udel.jatlas.gameframework;

public interface Move<S extends State<S>> {
    public boolean isValid(S state);
    public void make(S state);
}
