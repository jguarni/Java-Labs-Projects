package edu.udel.jguarni.app.blockevader;

import edu.udel.jatlas.gameframework.Player;
import edu.udel.jatlas.gameframework.Position;
import edu.udel.jguarni.blockevader.EvaderMove;
import edu.udel.jguarni.blockevader.EvaderState;
import edu.udel.jguarni.blockevader.JumpMove;
import edu.udel.jguarni.blockevader.Piece;

public class EvaderHumanPlayer implements Player<EvaderMove, EvaderState> {
    private EvaderMoveListener listener;

    public EvaderHumanPlayer(EvaderMoveListener listener) {
        this.listener = listener;
    }

    public EvaderMove getNextMove(EvaderState state) {
        Position moveTo = listener.getMoveToPosition();
        if (moveTo != null) {
            return new JumpMove(Piece.UP);
        }
        return null;
    }
    
    public String getIdentifier() {
        return "Human";
    }

    public String toString() {
        return getIdentifier();
    }
}
