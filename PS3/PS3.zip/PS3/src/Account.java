//Written by Joe Guarni [CISC 181 Fall Section 010]
// This class will represent an Account. A account is an object with an Id, Balance, Monthly Interest Rate, and a Balance Limit for credit.

public class Account {
	private String Id;
	private double balance;
	private double monthinterest;
	private double ballimit;

	public Account(String Id, double balance, double monthinterest) {
		this(Id, balance, monthinterest, 0);
		this.Id = Id;
		this.balance = balance;
		this.monthinterest = monthinterest;
	}

	public Account(String Id, double balance, double monthinterest,
			double ballimit) {
		this.Id = Id;
		this.balance = balance;
		this.monthinterest = monthinterest;
		this.ballimit = ballimit;
	}

	public String getId() {
		return Id;
	}

	public double getBalance() {
		return balance;
	}

	public double getMonthinterest() {
		return monthinterest;
	}

	public double getBallimit() {
		return ballimit;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	public void setMonthinterest(double monthinterest) {
		this.monthinterest = monthinterest;
	}

	public void setBallimit(double ballimit) {
		this.ballimit = ballimit;
	}

	public void setId(String Id) {
		this.Id = Id;
	}

	public void deposit(double amount) {
		this.balance = this.balance + amount;
	}

	public boolean withdraw(double amount) {
		// This method will withdraw a specified amount from an account.
		boolean a = false;
		if ((amount <= this.balance) || (this.balance - amount > this.ballimit)) {
			this.balance = this.balance - amount;
			a = true;
		}
		return a;
	}

	public void payoffBalance(Account fund) {
		// This method will pay the maximum amount towards the balance of a negative account from a positive balance account and deduct accordingly.
		if ((Math.abs(fund.balance) > this.balance) && (this.balance > 0)) {
			fund.balance += this.balance;
			this.balance = 0;
		} else if (this.balance > 0) {
			this.balance += fund.balance;
			fund.balance = 0;
		}
	}

	public void addMonthlyInterest() {
		//This method will add monthly interest based off the accounts monthly interest rate.
		this.balance = this.balance + (this.balance * this.monthinterest);
	}

}
