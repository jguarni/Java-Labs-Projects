package edu.udel.jatlas.tictactoe;


import java.util.ArrayList;
import java.util.List;

import edu.udel.jatlas.gameframework.AIPlayer;

public class TicTacToe5x5AI extends AIPlayer<TicTacToe5x5Move, TicTacToe5x5State> {
    private char symbol;
    
    public TicTacToe5x5AI(char symbol) {
        this.symbol = symbol;
    }
    
    public char getSymbol() {
        return symbol;
    }
    
    /**
     * Returns a list of all valid moves from a given state.
     * 
     * @param state
     * @return
     */
    public List<TicTacToe5x5Move> getAllValidMoves(TicTacToe5x5State state) {
        List<TicTacToe5x5Move> validMoves = new ArrayList<TicTacToe5x5Move>();
        for (int i = 0; i < 25; i++) {
            TicTacToe5x5Move move = new TicTacToe5x5Move(i / 5, i % 5);
            if (move.isValid(state)) {
                validMoves.add(move);
            }
        }
        return validMoves;
    }
    
    /**
     * Returns the max sequence found in any row, column, or diagonal.
     */
    public double getHeuristicScore(TicTacToe5x5State state) {
        return state.getMaxSequenceAnyDirection(new TicTacToe5x5Piece(symbol));
    }

    public String getIdentifier() {
        return String.valueOf(symbol);
    }
}
