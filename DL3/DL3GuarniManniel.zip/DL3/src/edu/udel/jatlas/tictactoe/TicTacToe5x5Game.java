package edu.udel.jatlas.tictactoe;


import edu.udel.jatlas.gameframework.ConsoleTickManager;
import edu.udel.jatlas.gameframework.Game;
import edu.udel.jatlas.gameframework.Player;


public class TicTacToe5x5Game extends Game<TicTacToe5x5Move, TicTacToe5x5State> {
    
    
    /**
     * Creates a random game starting state
     */
    public TicTacToe5x5Game() {
        this(new TicTacToe5x5State('x', 'o'));
        // make the state randomly change turn so that sometimes x starts and sometimes o starts
        if (Math.random() > 0.5) {
            getCurrentState().changeTurn();
        }
    }
    
    /**
     * Create a game using the given starting state.
     * 
     * @param startState
     */
    public TicTacToe5x5Game(TicTacToe5x5State startState) {
        super(startState);
    }
    
    public Player<TicTacToe5x5Move, TicTacToe5x5State> getCurrentPlayer() {
        return getPlayer(String.valueOf(getCurrentState().getTurn()));
    }
   
    public Player<TicTacToe5x5Move, TicTacToe5x5State> getWinner() {
        // check to see if there is a winner
        TicTacToe5x5State state = getCurrentState();
        if (state.isWinner(state.getTurn())) {
            return getPlayer(String.valueOf(state.getTurn()));
        }
        if (state.isWinner(state.getNotTurn())) {
            return getPlayer(String.valueOf(state.getNotTurn()));
        }
        return null;
    }

    public String toString() {
        String result = getCurrentState().toString();
        if (getCurrentState().isEnd()) {
            Player<TicTacToe5x5Move, TicTacToe5x5State> winner = getWinner();
            if (winner == null) {
                result += "Game is a draw.\n";
            }
            else {
                result += "Winner is player " + winner + ".\n";
            }
        }
        return result;
    }
    
    public static void main(String[] args) {
        TicTacToe5x5Game game = new TicTacToe5x5Game();
        game.addPlayer(new TicTacToe5x5AI('x'));
        game.addPlayer(new TicTacToe5x5AI('o'));
        ConsoleTickManager.manageGame(game);
    }
    
    
}
