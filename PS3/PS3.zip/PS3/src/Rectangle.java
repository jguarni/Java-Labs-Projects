//Written by Joe Guarni [CISC 181 Fall Section 010]
// This class will represent a rectangle. A rectangle is an object that has a width and height.

public class Rectangle {
	private double width;
	private double height;

	public Rectangle(double width, double height) {
		//Creates a rectangle with a specified width and height.
		this.width = width;
		this.height = height;
	}

	public Rectangle() {
		// Creates a default rectangle with one for both width and height.
		this.width = 1;
		this.height = 1;
	}

	public double getWidth() {
		return width;
	}

	public void setWidth(double width) {
		this.width = width;
	}

	public double getHeight() {
		return height;
	}

	public void setHeight(double height) {
		this.height = height;
	}

	public double getArea() {
		return width * height;
	}

	public double getPerimeter() {
		return ((2 * width) + (2 * height));
	}
	
	public static Rectangle makeGoldenRectangle(double height) {
		//This method will make a golden rectangle based off a specified height.
		double width = height * 1.61803398875;
		Rectangle goldenrec = new Rectangle(width, height);
		return goldenrec;
		
	}
}
