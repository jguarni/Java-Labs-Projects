package edu.udel.jatlas.tictactoe.android;

import android.app.Activity;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.LinearLayout;
import edu.udel.jatlas.gameframework.GameStateListener;
import edu.udel.jatlas.gameframework.Player;
import edu.udel.jatlas.gameframework.android.AndroidTickManager;
import edu.udel.jatlas.tictactoe.TicTacToe5x5AI;
import edu.udel.jatlas.tictactoe.TicTacToe5x5Game;
import edu.udel.jatlas.tictactoe.TicTacToe5x5Move;
import edu.udel.jatlas.tictactoe.TicTacToe5x5State;

/**
 * A simple Android activity for a TicTacToe5x5Game that creates 
 * a 2d view (or 3d view) and a text view to display a message.
 * 
 * Provides a minimal menu to choose what type of game to play.
 * 
 * @author jatlas
 *
 */
public class TicTacToe5x5Activity extends Activity {
    private View view;
    private Scoreboard scoreboard;
    
    private TicTacToe5x5Game game;
    private TicTacToe5x5TouchListener touchListener;
    
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
        initGUI();
        game = newOnePlayerGame();
        startGame(game);
    }
    
    public TicTacToe5x5Game getCurrentGame() {
        return game;
    }
    
    private void initGUI() {
        boolean is3d = false;
        try {
            ActivityInfo ai = getPackageManager().getActivityInfo(
                getComponentName(), PackageManager.GET_META_DATA);
            if (ai.metaData != null) {
                is3d = ai.metaData.getBoolean("edu.udel.jatlas.tictactoe.3d", true);
            }
        }
        catch (Exception e) {
            // no 3d for you!
            Log.e("TicTacToe5x5", "3d initialization failed", e);
        }
        
        scoreboard = new Scoreboard(this);
        LinearLayout withScoreboard = new LinearLayout(this);
        withScoreboard.setOrientation(LinearLayout.VERTICAL);
        withScoreboard.addView(scoreboard);
        
        if (is3d) {
            view = new TicTacToe5x5View3D(this);
        }
        else {
            view = new TicTacToe5x5View2D(this);
        }
        withScoreboard.addView(view);
        
        touchListener = new TicTacToe5x5TouchListener(this);
        view.setOnTouchListener(touchListener);
        
        
        
        setContentView(withScoreboard);
    }
    
    public boolean onCreateOptionsMenu(Menu menu){
        menu.add("AI Game");
        menu.add("1 Player Game");
        menu.add("2 Player Game");
        menu.add("Restart");
        menu.add("Quit");
        return true;
    }
    
    public boolean onOptionsItemSelected(MenuItem item) {
        CharSequence title = item.getTitle();
        if (title.equals("AI Game")) {
            game = newAIGame();
            startGame(game);
        }
        else if (title.equals("1 Player Game")) {
            game = newOnePlayerGame();
            startGame(game);
        }
        else if (title.equals("2 Player Game")) {
            game = newTwoPlayerGame();
            startGame(game);
        }
        else if (title.equals("Restart")) {
            // start a new game with the same players as previous game
            restartGame();
        }
        else if (title.equals("Quit")) {
            finish();
        }
        return true;
    }
    
    public void restartGame() {
        TicTacToe5x5Game newGame = new TicTacToe5x5Game();
        for (Player<TicTacToe5x5Move, TicTacToe5x5State> p : game.getPlayers()) {
            newGame.addPlayer(p);
        }
        game = newGame;
        startGame(game);
    }
    
    private void startGame(TicTacToe5x5Game game) {
        game.addStateChangeListener((GameStateListener)view);
        game.addStateChangeListener(scoreboard);
        
        game.start();
        AndroidTickManager.manageGame(game);
    }

    private TicTacToe5x5Game newAIGame() {
        TicTacToe5x5Game game = new TicTacToe5x5Game();
        game.addPlayer(new TicTacToe5x5AI('x'));
        game.addPlayer(new TicTacToe5x5AI('o'));
        return game;
    }
    

    private TicTacToe5x5Game newOnePlayerGame() {
        TicTacToe5x5Game game = new TicTacToe5x5Game();
        game.addPlayer(new TicTacToe5x5HumanPlayer('x', touchListener));
        game.addPlayer(new TicTacToe5x5AI('o'));
        return game;
    }
    

    private TicTacToe5x5Game newTwoPlayerGame() {
        TicTacToe5x5Game game = new TicTacToe5x5Game();
        game.addPlayer(new TicTacToe5x5HumanPlayer('x', touchListener));
        game.addPlayer(new TicTacToe5x5HumanPlayer('o', touchListener));
        return game;
    }
}