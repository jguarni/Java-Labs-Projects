package edu.udel.jatlas.gameframework;

import java.util.Iterator;

/**
 * Implements a general mutable Iterator that can handle
 * various linear iterations over a matrix.  This is a general
 * purpose version of the RowIterator/ColumnIterator/DiagonalIterator
 * from lecture and this one class can represent all of those patterns.
 * 
 * The reset method must be called after construction and
 * before using this Iterator. Once the Iterator is used, the reset
 * method allows it to be re-used again so that new Objects
 * are not created for every new iteration.
 * 
 * @author jatlas
 *
 */
public class LinearIterator<T> implements Iterator<T> {
    private T[][] matrix;
    private int row;
    private int col;
    private int incRow;
    private int incCol;
    

    public LinearIterator(T[][] matrix) {
        this.matrix = matrix;
    }

    public boolean hasNext() {
        return row >= 0 && row < matrix.length && col >= 0 
                && col < matrix[row].length;
    }

    public T next() {
        T result = matrix[row][col];
        row+=incRow;
        col+=incCol;
        return result;
    }
    
    public void reset(int row, int col) {
        this.row = row;
        this.col = col;
    }
    
    public void reset(int row, int col, int incRow, int incCol) {
        reset(row, col);
        this.incRow = incRow;
        this.incCol = incCol;
    }

    public void remove() {
        // do not need to implement remove
    }

}
