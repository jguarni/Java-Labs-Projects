package edu.udel.jguarni.blockevader;

import edu.udel.jatlas.gameframework.Position;
//This class will create a block obejct. A block is an object that the evader needs to avoid. A block has a width, height, color, type and
//position defined by its row and column.
import edu.udel.jguarni.blockevader.EvaderState;

public class Block extends Piece<Block> {
	public static final int DIRECTION_LEFT = 1;
	public static final int DIRECTION_STILL = 0;
	public static final int DIRECTION_DOWN = 2;

	private Position position;
	private int direction;

	public Block(Position position, int direction) {
		super(position);
		this.position = position;
		this.direction = direction;
	}

	// SEtters and Getters
	public Position getBlock() {
		return this.position;
	}

	public char getSymbol() {
		return 'B';
	}

	public int getDirection() {
		return direction;
	}
	public void setDirection(int direction) {
		this.direction = direction;
	}
	public Position getPosition() {
		return position;
	}

	public void setPosition(Position position) {
		this.position = position;
	}

	public Block copy() {
		return this;
	}

	public void onTick(EvaderState state) {
		this.position = new Position(this.getPosition().getRow(), this.getPosition().getCol() -1);
		
		
		}
		
}

